import { oAuthClientId, auth, googleAuthProvider } from './firebase';
import { signInWithPopup, GoogleAuthProvider, User } from 'firebase/auth';

export interface WorkspaceTokenState {
  accessToken: string | null;
  expiresAt: number | null;
  email?: string;
  name?: string;
}

const SCOPES = [
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/calendar.events',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/contacts',
].join(' ');

/**
 * Robust Google Workspace authentication combining Firebase Auth & GIS
 */
export async function signInGoogleWorkspace(): Promise<{ token: string; user?: User } | null> {
  // 1. Try Firebase Auth popup
  try {
    const result = await signInWithPopup(auth, googleAuthProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      return { token: credential.accessToken, user: result.user };
    }
  } catch (fbErr: any) {
    console.warn('Firebase signInWithPopup info:', fbErr?.code || fbErr?.message);
    if (fbErr?.code === 'auth/popup-closed-by-user' || fbErr?.code === 'auth/cancelled-popup-request') {
      return null;
    }
  }

  // 2. Fallback to GIS Token Client if Firebase popup is blocked in iframe
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !(window as any).google?.accounts?.oauth2) {
      resolve(null);
      return;
    }

    try {
      const tokenClient = (window as any).google.accounts.oauth2.initTokenClient({
        client_id: oAuthClientId,
        scope: SCOPES,
        callback: (tokenResponse: any) => {
          if (tokenResponse.error) {
            console.warn('GIS OAuth response:', tokenResponse.error);
            resolve(null);
          } else if (tokenResponse.access_token) {
            resolve({ token: tokenResponse.access_token });
          } else {
            resolve(null);
          }
        },
      });

      tokenClient.requestAccessToken({ prompt: 'select_account' });
    } catch (err) {
      console.warn('GIS Token client error:', err);
      resolve(null);
    }
  });
}

/**
 * Request an access token using Google Identity Services (GIS)
 */
export function requestGoogleWorkspaceToken(
  onSuccess: (token: string) => void,
  onError?: (err: any) => void
) {
  signInGoogleWorkspace().then((res) => {
    if (res?.token) {
      onSuccess(res.token);
    } else {
      onError?.(new Error('Google Workspace authorization was not completed.'));
    }
  });
}

/**
 * 1. GOOGLE CALENDAR INTEGRATION
 * Creates an event on the user's primary Google Calendar for a scheduled appointment.
 */
export async function createGoogleCalendarEvent(
  accessToken: string,
  appointment: {
    patientName: string;
    doctorName: string;
    department: string;
    date: string; // YYYY-MM-DD
    time: string; // e.g. "10:30 AM" or "14:00"
    tokenNumber: string;
    clinicName?: string;
    reason?: string;
  }
): Promise<{ eventId: string; htmlLink: string }> {
  // Parse date and time into ISO string
  const startDateTime = new Date(`${appointment.date} ${appointment.time || '10:00 AM'}`);
  const endDateTime = new Date(startDateTime.getTime() + 30 * 60 * 1000); // 30 min duration

  const eventPayload = {
    summary: `🩺 ClinicOS: Token ${appointment.tokenNumber} - ${appointment.patientName} with ${appointment.doctorName}`,
    description: `Clinic Consultation at ${appointment.clinicName || 'Apex Metro Clinic'}\n\nPatient: ${appointment.patientName}\nDoctor: ${appointment.doctorName} (${appointment.department})\nToken: ${appointment.tokenNumber}\nChief Complaint: ${appointment.reason || 'General Consultation'}\n\nManage seamlessly in ClinicOS.`,
    location: `${appointment.clinicName || 'Apex Metro Clinic'}, OPD Wing, Floor 1`,
    start: {
      dateTime: startDateTime.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    end: {
      dateTime: endDateTime.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    },
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'popup', minutes: 30 },
        { method: 'email', minutes: 60 },
      ],
    },
  };

  const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(eventPayload),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Google Calendar API error: ${errorText}`);
  }

  const data = await response.json();
  return {
    eventId: data.id,
    htmlLink: data.htmlLink,
  };
}

/**
 * 2. GOOGLE SHEETS INTEGRATION
 * Creates a formatted spreadsheet or appends data for ClinicOS records.
 */
export async function exportToGoogleSheet(
  accessToken: string,
  title: string,
  headers: string[],
  rows: (string | number)[][]
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  // Step 1: Create a new spreadsheet
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: `ClinicOS — ${title} (${new Date().toLocaleDateString()})`,
      },
      sheets: [
        {
          properties: {
            title: 'Report Data',
            gridProperties: {
              frozenRowCount: 1,
            },
          },
        },
      ],
    }),
  });

  if (!createRes.ok) {
    const err = await createRes.text();
    throw new Error(`Failed to create Google Sheet: ${err}`);
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;

  // Step 2: Append headers and rows
  const allValues = [headers, ...rows];
  const appendRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Report Data!A1:append?valueInputOption=USER_ENTERED`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: allValues,
      }),
    }
  );

  if (!appendRes.ok) {
    const err = await appendRes.text();
    throw new Error(`Failed to populate Google Sheet: ${err}`);
  }

  return {
    spreadsheetId,
    spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${spreadsheetId}`,
  };
}

/**
 * 3. GMAIL INTEGRATION
 * Dispatches real emails (e.g. Appointment Confirmation, Prescription, Invoices) via Gmail API.
 */
export async function sendGmailMessage(
  accessToken: string,
  params: {
    to: string;
    subject: string;
    bodyHtml: string;
    clinicName?: string;
  }
): Promise<{ messageId: string }> {
  const clinic = params.clinicName || 'ClinicOS — Apex Metro Clinic';

  // Construct MIME message (RFC 2822)
  const utf8Subject = `=?utf-8?B?${btoa(unescape(encodeURIComponent(params.subject)))}?=`;
  const messageParts = [
    `To: ${params.to}`,
    'Content-Type: text/html; charset=utf-8',
    'MIME-Version: 1.0',
    `Subject: ${utf8Subject}`,
    '',
    `<!DOCTYPE html>
    <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #1e293b; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #0d9488, #0f766e); padding: 18px 24px; border-radius: 8px 8px 0 0; color: white;">
          <h2 style="margin: 0; font-size: 20px; font-weight: bold;">🏥 ${clinic}</h2>
          <p style="margin: 4px 0 0 0; opacity: 0.9; font-size: 13px;">Official Patient Communication</p>
        </div>
        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-top: none; padding: 24px; border-radius: 0 0 8px 8px;">
          ${params.bodyHtml}
          <hr style="margin: 24px 0; border: none; border-top: 1px solid #e2e8f0;" />
          <p style="font-size: 12px; color: #64748b; margin: 0;">
            This email was sent securely via ClinicOS Cloud Integration.
          </p>
        </div>
      </body>
    </html>`,
  ];

  const rawMessage = messageParts.join('\r\n');
  const encodedMessage = btoa(unescape(encodeURIComponent(rawMessage)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: encodedMessage }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Gmail API send failed: ${errorText}`);
  }

  const result = await response.json();
  return { messageId: result.id };
}

/**
 * 4. GOOGLE CONTACTS INTEGRATION
 * Syncs patients directly into Google Contacts via People API.
 */
export async function createGoogleContact(
  accessToken: string,
  patient: {
    name: string;
    phone: string;
    email?: string;
    patientCode: string;
    bloodGroup?: string;
  }
): Promise<{ resourceName: string }> {
  const [givenName, ...familyParts] = patient.name.split(' ');
  const familyName = familyParts.join(' ') || '';

  const contactPayload = {
    names: [
      {
        givenName,
        familyName,
        displayName: patient.name,
      },
    ],
    phoneNumbers: [
      {
        value: patient.phone,
        type: 'mobile',
      },
    ],
    ...(patient.email ? { emailAddresses: [{ value: patient.email, type: 'home' }] } : {}),
    userDefined: [
      { key: 'ClinicOS Patient Code', value: patient.patientCode },
      { key: 'Blood Group', value: patient.bloodGroup || 'Not specified' },
      { key: 'Facility', value: 'Apex Metro Clinic' },
    ],
    biographies: [
      {
        value: `Patient registered at ClinicOS (Code: ${patient.patientCode}, Blood Group: ${patient.bloodGroup || 'N/A'}).`,
        contentType: 'TEXT_PLAIN',
      },
    ],
  };

  const response = await fetch('https://people.googleapis.com/v1/people:createContact', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(contactPayload),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Google Contacts API error: ${errText}`);
  }

  const result = await response.json();
  return { resourceName: result.resourceName };
}
