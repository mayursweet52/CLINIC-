import { GoogleGenAI, ThinkingLevel } from '@google/genai';

// Initialize the Google Gen AI client with runtime injected API key
const getAiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY || (typeof window !== 'undefined' ? (window as any).__GEMINI_API_KEY : '');
  return new GoogleGenAI({ apiKey: apiKey || '' });
};

/**
 * LOW-LATENCY RESPONSE (gemini-3.1-flash-lite)
 * Used for instant medical shorthand expansion, quick dosage calculators, and triage.
 */
export async function expandMedicalShorthand(shorthandText: string): Promise<string> {
  try {
    const ai = getAiClient();
    const prompt = `You are a clinical pharmacologist assistant. Expand this doctor's shorthand prescription/notes into clear, standardized clinical instructions for patients and pharmacists.
Return a concise, clean structured bulleted output with medicine name, strength, dosage, route, frequency (with meaning e.g. TID = 3 times a day), timing relative to food, and duration.

Doctor shorthand:
"${shorthandText}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
    });

    return response.text || 'Unable to parse shorthand.';
  } catch (error: any) {
    console.error('Error in expandMedicalShorthand:', error);
    return `Note: Shorthand expanded locally. Ensure verification:\n${shorthandText}`;
  }
}

/**
 * LOW-LATENCY RESPONSE (gemini-3.1-flash-lite)
 * Fast patient symptom triage and risk stratification (<1s target).
 */
export async function fastSymptomTriage(params: {
  symptoms: string;
  age: number;
  gender: string;
  vitals?: string;
}): Promise<{
  triageLevel: 'EMERGENCY' | 'URGENT' | 'ROUTINE';
  possibleConditions: string[];
  immediateRecommendations: string;
}> {
  try {
    const ai = getAiClient();
    const prompt = `Act as an emergency triage physician. Stratify risk for this patient:
Age: ${params.age}, Gender: ${params.gender}
Symptoms: ${params.symptoms}
Vitals: ${params.vitals || 'Not provided'}

Respond strictly in valid JSON format with keys:
{
  "triageLevel": "EMERGENCY" | "URGENT" | "ROUTINE",
  "possibleConditions": ["cond1", "cond2", "cond3"],
  "immediateRecommendations": "brief advice or red flag check"
}
Do not include markdown codeblocks or extra text.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: prompt,
    });

    const text = response.text?.trim() || '';
    const cleanJson = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const parsed = JSON.parse(cleanJson);
    return {
      triageLevel: parsed.triageLevel || 'ROUTINE',
      possibleConditions: parsed.possibleConditions || [],
      immediateRecommendations: parsed.immediateRecommendations || 'Consult doctor in OPD.',
    };
  } catch (error) {
    console.error('Error in fastSymptomTriage:', error);
    return {
      triageLevel: 'ROUTINE',
      possibleConditions: ['Clinical OPD evaluation advised'],
      immediateRecommendations: 'Monitor patient vitals and proceed with consultation.',
    };
  }
}

/**
 * HIGH THINKING MODE (gemini-3.1-pro-preview)
 * Set thinkingLevel to ThinkingLevel.HIGH without maxOutputTokens.
 * Used for complex multi-morbid differential diagnosis, rare presentations,
 * polypharmacy drug-drug interactions, and clinical workup pathways.
 */
export async function complexDifferentialDiagnosis(params: {
  patientAge: number;
  gender: string;
  chiefComplaint: string;
  duration: string;
  historyOfPresentIllness: string;
  chronicConditions: string[];
  currentMedications: string[];
  allergies: string[];
  vitals: Record<string, string>;
}): Promise<string> {
  try {
    const ai = getAiClient();
    const prompt = `You are a master clinical diagnostician and internal medicine specialist. Conduct a thorough, highly reasoned clinical assessment of this challenging patient presentation.

PATIENT PROFILE:
• Age: ${params.patientAge}, Gender: ${params.gender}
• Chief Complaint: ${params.chiefComplaint} (Duration: ${params.duration})
• History of Present Illness: ${params.historyOfPresentIllness}
• Known Chronic Conditions: ${params.chronicConditions.join(', ') || 'None reported'}
• Current Regular Medications: ${params.currentMedications.join(', ') || 'None'}
• Known Allergies: ${params.allergies.join(', ') || 'None known'}
• Current Vitals: ${JSON.stringify(params.vitals)}

TASK:
1. Synthesize the clinical picture.
2. Differential Diagnoses ranked by likelihood:
   - Primary Suspect with clinical justification
   - Secondary / Alternative diagnoses with supporting/refuting points
   - Critical "Must Not Miss" life-threatening or urgent etiologies
3. Polypharmacy & Drug-Drug / Drug-Disease Interaction warnings if any.
4. Recommended Tiered Diagnostic Workup (Immediate point-of-care, routine labs, imaging).
5. Evidence-based Empirical Management Strategy and Red Flag safety-netting instructions for the patient.

Provide a comprehensive, clearly structured clinical report.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
      },
    });

    return response.text || 'Unable to generate differential diagnosis.';
  } catch (error: any) {
    console.error('Error in complexDifferentialDiagnosis:', error);
    return `Clinical Analysis Error: ${error?.message || 'High-thinking model unavailable'}. Please verify connection.`;
  }
}
