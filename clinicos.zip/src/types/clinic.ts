export type UserRole = 'DOCTOR' | 'RECEPTIONIST' | 'PHARMACIST' | 'ADMIN' | 'PATIENT';

export type ApptStatus = 
  | 'SCHEDULED' 
  | 'ARRIVED' 
  | 'IN_CONSULTATION' 
  | 'COMPLETED' 
  | 'CANCELLED' 
  | 'NO_SHOW';

export type PaymentStatus = 'PENDING' | 'PAID' | 'PARTIAL' | 'REFUNDED';

export interface DoctorProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialty: string;
  department: string;
  qualification: string;
  experienceYears: number;
  consultationFee: number;
  roomNumber: string;
  avatarUrl?: string;
  isActive: boolean;
}

export interface Patient {
  id: string;
  organizationId: string;
  patientCode: string; // e.g. AMC-2024-0147
  name: string;
  phone: string;
  email?: string;
  age: number;
  gender: 'MALE' | 'FEMALE' | 'OTHER';
  bloodGroup: string;
  address?: string;
  allergies: string[];
  chronicConditions: string[];
  createdAt: string;
  syncedToGoogleContacts?: boolean;
}

export interface HealthAppointment {
  id: string;
  organizationId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientAge?: number;
  patientGender?: string;
  doctorId: string;
  doctorName: string;
  department: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // "10:30 AM"
  tokenNumber: string; // e.g. "Q-104"
  status: ApptStatus;
  reason?: string;
  notes?: string;
  checkedInAt?: string;
  consultationStartedAt?: string;
  completedAt?: string;
  createdAt: string;
  googleCalendarEventId?: string;
}

export interface MedicineItem {
  id: string;
  medicineName: string;
  dosage: string; // "650mg"
  frequency: string; // "1-0-1 (Twice daily)" or "TID"
  duration: string; // "5 days"
  instructions: string; // "After meals with warm water"
  quantity: number;
  unitPrice?: number;
}

export interface Prescription {
  id: string;
  organizationId: string;
  appointmentId: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  diagnosis: string;
  symptoms: string[];
  vitals?: {
    bp?: string;
    pulse?: string;
    temp?: string;
    spo2?: string;
    weight?: string;
  };
  medicines: MedicineItem[];
  advice?: string;
  followUpDate?: string;
  status: 'PENDING' | 'DISPENSED' | 'PARTIAL';
  createdAt: string;
  dispensedAt?: string;
}

export interface InventoryItem {
  id: string;
  organizationId: string;
  medicineName: string;
  genericName: string;
  category: 'Tablet' | 'Capsule' | 'Syrup' | 'Injection' | 'Ointment' | 'Drops';
  batchNumber: string;
  quantity: number;
  unitPrice: number;
  reorderLevel: number;
  expiryDate: string;
  manufacturer: string;
}

export interface Billing {
  id: string;
  organizationId: string;
  appointmentId: string;
  patientId: string;
  patientName: string;
  invoiceNumber: string; // e.g. "INV-2026-089"
  consultationFee: number;
  medicineCharges: number;
  labCharges: number;
  discount: number;
  totalAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod?: 'CASH' | 'UPI' | 'CARD' | 'ONLINE';
  paidAt?: string;
  createdAt: string;
  syncedToGoogleSheet?: boolean;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  role: UserRole;
  action: string;
  resource: string;
  resourceId?: string;
  details: string;
  timestamp: string;
}

export interface DoctorTimeOff {
  id: string;
  doctorId: string;
  doctorName: string;
  date: string;
  reason: string;
  createdAt: string;
}
