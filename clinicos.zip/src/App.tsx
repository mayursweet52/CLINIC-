/**
 * ClinicOS — Multi-Tenant OPD Realtime Clinic Management Platform
 * Dedicated Separate Page Architecture
 */

import React, { useState, useEffect } from 'react';
import { ClinicProvider, useClinic } from './context/ClinicContext';
import { Header, AppPageId } from './components/layout/Header';
import { AppointmentBookingPage } from './components/booking/AppointmentBookingPage';
import { DoctorDashboard } from './components/doctor/DoctorDashboard';
import { ReceptionQueue } from './components/reception/ReceptionQueue';
import { PharmacyDashboard } from './components/pharmacy/PharmacyDashboard';
import { BillingDashboard } from './components/billing/BillingDashboard';
import { PatientDirectory } from './components/patients/PatientDirectory';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { ToastNotification } from './components/shared/ToastNotification';
import { Cloud, Activity } from 'lucide-react';

function getInitialPage(): AppPageId {
  if (typeof window !== 'undefined') {
    const hash = window.location.hash.replace('#', '').toUpperCase();
    if (['BOOKING', 'RECEPTION', 'DOCTOR', 'PHARMACY', 'BILLING', 'PATIENTS', 'ADMIN'].includes(hash)) {
      return hash as AppPageId;
    }
  }
  return 'BOOKING';
}

function AppContent() {
  const [activePage, setActivePage] = useState<AppPageId>(getInitialPage());

  // Keep browser hash in sync with active page
  const handlePageChange = (page: AppPageId) => {
    setActivePage(page);
    if (typeof window !== 'undefined') {
      window.location.hash = page.toLowerCase();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').toUpperCase();
      if (['BOOKING', 'RECEPTION', 'DOCTOR', 'PHARMACY', 'BILLING', 'PATIENTS', 'ADMIN'].includes(hash)) {
        setActivePage(hash as AppPageId);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <div className="min-h-screen bg-[#f8f7f4] text-[#1a1a1a] flex flex-col selection:bg-[#4a6659] selection:text-white">
      {/* Top Application Header & Primary 7-Page Navigator */}
      <Header activePage={activePage} setActivePage={handlePageChange} />

      {/* Main Viewport: Completely Separate Pages */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-12 py-8 sm:py-12">
        {activePage === 'BOOKING' && (
          <AppointmentBookingPage onNavigateToPage={handlePageChange} />
        )}

        {activePage === 'RECEPTION' && (
          <ReceptionQueue />
        )}

        {activePage === 'DOCTOR' && (
          <DoctorDashboard />
        )}

        {activePage === 'PHARMACY' && (
          <PharmacyDashboard />
        )}

        {activePage === 'BILLING' && (
          <BillingDashboard />
        )}

        {activePage === 'PATIENTS' && (
          <PatientDirectory />
        )}

        {activePage === 'ADMIN' && (
          <AdminDashboard />
        )}
      </main>

      {/* Toast Notification Container */}
      <ToastNotification />

      {/* Variation 3 Architectural Footer */}
      <footer className="border-t border-[#e5e2db] py-6 px-4 sm:px-8 lg:px-16 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#666666] bg-[#f8f7f4] mt-auto">
        <div className="flex items-center">
          <span className="pulse"></span>
          <span>Firestore Realtime Protocol Active</span>
        </div>
        <div>
          Apex Metro Clinic • Multi-Tenant Cloud Architecture v2.4
        </div>
        <div className="italic">
          Gemini 3.1 &amp; Workspace Integration Enabled
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ClinicProvider>
      <AppContent />
    </ClinicProvider>
  );
}
