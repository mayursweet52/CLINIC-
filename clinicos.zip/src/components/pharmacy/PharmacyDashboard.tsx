import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Pill, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Package, 
  Plus, 
  Search, 
  Mail, 
  X,
  FileText
} from 'lucide-react';
import { InventoryItem, Prescription } from '../../types/clinic';

export function PharmacyDashboard() {
  const {
    prescriptions,
    inventory,
    patients,
    dispensePrescription,
    addInventoryItem,
    updateInventoryStock,
    sendPrescriptionEmail,
    workspaceToken,
    showToast,
  } = useClinic();

  const [activeTab, setActiveTab] = useState<'pending' | 'inventory'>('pending');
  const [selectedRx, setSelectedRx] = useState<Prescription | null>(null);
  const [isDispensing, setIsDispensing] = useState(false);
  const [isAddMedModalOpen, setIsAddMedModalOpen] = useState(false);
  const [inventorySearch, setInventorySearch] = useState('');

  // New Medicine form state
  const [newMedName, setNewMedName] = useState('');
  const [newMedGeneric, setNewMedGeneric] = useState('');
  const [newMedCategory, setNewMedCategory] = useState<InventoryItem['category']>('Tablet');
  const [newMedBatch, setNewMedBatch] = useState('');
  const [newMedQty, setNewMedQty] = useState(100);
  const [newMedPrice, setNewMedPrice] = useState(10);
  const [newMedReorder, setNewMedReorder] = useState(50);
  const [newMedExpiry, setNewMedExpiry] = useState('2028-12-31');
  const [newMedManufacturer, setNewMedManufacturer] = useState('Apex Labs');

  const pendingPrescriptions = prescriptions.filter((p) => p.status === 'PENDING');
  const dispensedPrescriptions = prescriptions.filter((p) => p.status === 'DISPENSED');

  const filteredInventory = inventory.filter((item) => {
    return (
      item.medicineName.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      item.genericName.toLowerCase().includes(inventorySearch.toLowerCase()) ||
      item.batchNumber.toLowerCase().includes(inventorySearch.toLowerCase())
    );
  });

  const lowStockItems = inventory.filter((i) => i.quantity <= i.reorderLevel);

  // Dispense action
  const handleDispense = async (rx: Prescription) => {
    try {
      setIsDispensing(true);
      const itemsToDeduct = rx.medicines.map((m) => {
        const inv = inventory.find(
          (i) => i.medicineName.toLowerCase() === m.medicineName.toLowerCase()
        ) || inventory[0];
        return {
          medicineId: inv.id,
          quantity: m.quantity || 10,
        };
      });

      await dispensePrescription(rx.id, itemsToDeduct);
      setSelectedRx(null);
    } catch (err: any) {
      showToast('Dispense Error', err?.message || 'Failed to dispense', 'error');
    } finally {
      setIsDispensing(false);
    }
  };

  // Add new medicine batch
  const handleCreateMedicine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName || !newMedBatch) return;

    try {
      await addInventoryItem({
        organizationId: 'org-apex-01',
        medicineName: newMedName,
        genericName: newMedGeneric,
        category: newMedCategory,
        batchNumber: newMedBatch,
        quantity: Number(newMedQty),
        unitPrice: Number(newMedPrice),
        reorderLevel: Number(newMedReorder),
        expiryDate: newMedExpiry,
        manufacturer: newMedManufacturer,
      });

      setIsAddMedModalOpen(false);
      setNewMedName('');
      setNewMedGeneric('');
      setNewMedBatch('');
      showToast('Inventory Updated', `${newMedName} added to pharmaceutical catalog.`, 'success');
    } catch (err: any) {
      showToast('Error', err?.message || 'Failed to add medicine', 'error');
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="border-b border-[#e5e2db] pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
            Pharmacy &amp; Dispensary
          </h2>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            Real-time e-prescription fulfillment &bull; Drug inventory control
          </p>
        </div>

        <div className="flex items-center gap-3">
          {lowStockItems.length > 0 && (
            <div className="px-3 py-1.5 border border-[#e5e2db] bg-white text-[#a83232] text-xs font-semibold flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-[#a83232]" />
              <span>{lowStockItems.length} Low Stock Alert(s)</span>
            </div>
          )}
          <button
            onClick={() => setIsAddMedModalOpen(true)}
            className="btn-editorial flex items-center gap-2"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Stock Item</span>
          </button>
        </div>
      </div>

      {/* Quick KPI Stat Blocks */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="stat-block">
          <span className="stat-label">Pending Dispenses</span>
          <div className="stat-val mt-1">{pendingPrescriptions.length}</div>
          <span className="text-[11px] text-[#666666] mt-1 block">Awaiting fulfillment</span>
        </div>
        <div className="stat-block">
          <span className="stat-label">Fulfilled Today</span>
          <div className="stat-val mt-1">{dispensedPrescriptions.length}</div>
          <span className="text-[11px] text-[#4a6659] mt-1 block">Dispatched to patients</span>
        </div>
        <div className="stat-block">
          <span className="stat-label">Catalog Items</span>
          <div className="stat-val mt-1">{inventory.length}</div>
          <span className="text-[11px] text-[#666666] mt-1 block">Active medicine SKUs</span>
        </div>
        <div className="stat-block">
          <span className="stat-label">Low Stock Reorders</span>
          <div className="stat-val mt-1 text-[#a83232]">{lowStockItems.length}</div>
          <span className="text-[11px] text-[#666666] mt-1 block">Below reorder safety mark</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-8 border-b border-[#e5e2db]">
        <button
          onClick={() => setActiveTab('pending')}
          className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
            activeTab === 'pending'
              ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
              : 'text-[#666666] hover:text-[#1a1a1a]'
          }`}
        >
          Pending E-Prescriptions ({pendingPrescriptions.length})
        </button>
        <button
          onClick={() => setActiveTab('inventory')}
          className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
            activeTab === 'inventory'
              ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
              : 'text-[#666666] hover:text-[#1a1a1a]'
          }`}
        >
          Medicine Inventory ({inventory.length})
        </button>
      </div>

      {/* TAB 1: E-Prescriptions Queue */}
      {activeTab === 'pending' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* List of Prescriptions */}
          <div className="lg:col-span-7 space-y-4">
            {pendingPrescriptions.length === 0 ? (
              <div className="bg-white border border-[#e5e2db] p-12 text-center text-[#666666] shadow-xs">
                <CheckCircle2 className="w-10 h-10 mx-auto text-[#4a6659] mb-3 opacity-80" />
                <h4 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">
                  All Prescriptions Dispensed
                </h4>
                <p className="text-xs text-[#666666] mt-1">
                  New e-prescriptions finalized by doctors in consultation will arrive here automatically.
                </p>
              </div>
            ) : (
              pendingPrescriptions.map((rx) => {
                const pat = patients.find((p) => p.id === rx.patientId);
                const isSelected = selectedRx?.id === rx.id;

                return (
                  <div
                    key={rx.id}
                    onClick={() => setSelectedRx(rx)}
                    className={`bg-white border p-6 transition cursor-pointer shadow-xs ${
                      isSelected
                        ? 'border-[#1a1a1a] ring-1 ring-[#1a1a1a]'
                        : 'border-[#e5e2db] hover:border-[#666666]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-3">
                          <h4 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">{rx.patientName}</h4>
                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border border-[#e5e2db] text-[#4a6659] bg-[#f8f7f4]">
                            Pending Dispense
                          </span>
                        </div>
                        <p className="text-xs text-[#666666] mt-1">
                          Prescribed by <strong className="text-[#1a1a1a]">{rx.doctorName}</strong> &bull; {new Date(rx.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDispense(rx);
                        }}
                        disabled={isDispensing}
                        className="btn-editorial text-xs py-1.5 px-3 disabled:opacity-50"
                      >
                        Dispense Now
                      </button>
                    </div>

                    {/* Diagnosis & Medicine Pills */}
                    <div className="mt-4 pt-4 border-t border-[#e5e2db]">
                      <div className="text-xs text-[#1a1a1a] mb-2">
                        <strong className="text-[#666666]">Diagnosis:</strong> {rx.diagnosis}
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {rx.medicines.map((m, idx) => (
                          <span
                            key={idx}
                            className="text-xs px-2.5 py-1 border border-[#e5e2db] bg-[#f8f7f4] text-[#1a1a1a]"
                          >
                            {m.medicineName} ({m.dosage}) &bull; {m.frequency}
                          </span>
                        ))}
                      </div>

                      {pat?.allergies && pat.allergies.length > 0 && (
                        <div className="mt-3 text-xs text-[#a83232] font-semibold flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5 text-[#a83232]" />
                          <span>Allergy Alert: {pat.allergies.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {/* Past Dispensed History */}
            {dispensedPrescriptions.length > 0 && (
              <div className="pt-6">
                <h4 className="form-section-label">
                  Recently Dispensed Today ({dispensedPrescriptions.length})
                </h4>
                <div className="bg-white border border-[#e5e2db] divide-y divide-[#e5e2db]">
                  {dispensedPrescriptions.slice(0, 5).map((rx) => (
                    <div key={rx.id} className="p-3.5 px-4 flex items-center justify-between text-xs text-[#1a1a1a]">
                      <div>
                        <span className="font-semibold">{rx.patientName}</span>
                        <span className="text-[#666666] ml-2">({rx.diagnosis})</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">
                          Dispensed
                        </span>
                        <button
                          onClick={() => sendPrescriptionEmail(rx.id)}
                          className="p-1 border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition cursor-pointer"
                          title="Dispatch digital copy via Gmail"
                        >
                          <Mail className="w-3.5 h-3.5 text-[#4a6659]" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Preview Drawer: Selected Prescription Detail */}
          <div className="lg:col-span-5 bg-white border border-[#e5e2db] p-6 shadow-xs space-y-5">
            <h4 className="font-cormorant text-2xl font-semibold text-[#1a1a1a] border-b border-[#e5e2db] pb-3">
              Dispense Station
            </h4>

            {selectedRx ? (
              <div className="space-y-5 text-xs">
                <div>
                  <span className="stat-label">Patient Record</span>
                  <div className="font-semibold text-sm text-[#1a1a1a] mt-0.5">{selectedRx.patientName}</div>
                  <div className="text-[#666666] mt-0.5">Doctor: {selectedRx.doctorName}</div>
                  <div className="text-[#666666]">Diagnosis: {selectedRx.diagnosis}</div>
                </div>

                <div className="space-y-3 border-t border-[#e5e2db] pt-4">
                  <span className="stat-label">Medications in Order</span>
                  {selectedRx.medicines.map((m, i) => {
                    const invItem = inventory.find(
                      (inv) => inv.medicineName.toLowerCase() === m.medicineName.toLowerCase()
                    );
                    const isAvailable = invItem && invItem.quantity >= (m.quantity || 10);

                    return (
                      <div key={i} className="p-3 border border-[#e5e2db] bg-[#f8f7f4]">
                        <div className="flex items-center justify-between font-semibold text-[#1a1a1a]">
                          <span>{m.medicineName}</span>
                          <span className={isAvailable ? 'text-[#4a6659]' : 'text-[#a83232] font-semibold'}>
                            {invItem ? `${invItem.quantity} in stock` : 'Out of stock'}
                          </span>
                        </div>
                        <div className="text-[11px] text-[#666666] mt-1">
                          Dosage: {m.dosage} &bull; {m.frequency} &bull; {m.duration}
                        </div>
                        <div className="text-[11px] text-[#666666] mt-0.5">
                          Instructions: {m.instructions}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {selectedRx.advice && (
                  <div className="border-t border-[#e5e2db] pt-3 text-[#666666]">
                    <strong className="text-[#1a1a1a]">Doctor's Advice:</strong> {selectedRx.advice}
                  </div>
                )}

                <div className="pt-2">
                  <button
                    disabled={isDispensing}
                    onClick={() => handleDispense(selectedRx)}
                    className="btn-editorial w-full py-2.5 disabled:opacity-50"
                  >
                    {isDispensing ? 'Processing Dispense...' : 'Confirm Dispense & Charge to Invoice'}
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#666666] text-center py-12 italic">
                Select a pending prescription from the queue to verify quantities and dispense stock.
              </p>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: Medicine Inventory Table */}
      {activeTab === 'inventory' && (
        <div className="bg-white border border-[#e5e2db] shadow-xs space-y-4">
          <div className="p-4 border-b border-[#e5e2db] bg-[#f8f7f4] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-3.5 h-3.5 text-[#666666] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search catalog by brand name, generic formula, or batch #..."
                value={inventorySearch}
                onChange={(e) => setInventorySearch(e.target.value)}
                className="input-hairline pl-8 text-xs py-1.5"
              />
            </div>
            <span className="text-xs text-[#666666] font-medium">
              Active Catalog: {inventory.length} formulations
            </span>
          </div>

          <div className="overflow-x-auto p-4 pt-0">
            <table className="queue-table">
              <thead>
                <tr>
                  <th>Medicine &amp; Generic</th>
                  <th>Category</th>
                  <th>Batch #</th>
                  <th>Quantity In Stock</th>
                  <th>Unit Price</th>
                  <th>Expiry Date</th>
                  <th className="text-right">Quick Stock Adjustment</th>
                </tr>
              </thead>
              <tbody>
                {filteredInventory.map((item) => {
                  const isLow = item.quantity <= item.reorderLevel;

                  return (
                    <tr key={item.id}>
                      <td>
                        <strong className="font-semibold text-[#1a1a1a]">{item.medicineName}</strong>
                        <div className="text-xs text-[#666666]">{item.genericName}</div>
                      </td>
                      <td>
                        <span className="text-xs text-[#666666]">
                          {item.category}
                        </span>
                      </td>
                      <td className="text-xs font-mono text-[#666666]">
                        {item.batchNumber}
                      </td>
                      <td>
                        <span className={`font-semibold ${isLow ? 'text-[#a83232]' : 'text-[#1a1a1a]'}`}>
                          {item.quantity} units
                        </span>
                        {isLow && (
                          <span className="ml-2 text-[10px] font-bold uppercase tracking-wider text-[#a83232] border border-[#e5e2db] px-1.5 py-0.5 bg-white">
                            Low Stock
                          </span>
                        )}
                      </td>
                      <td className="text-xs font-semibold text-[#1a1a1a]">
                        ₹{item.unitPrice.toFixed(2)}
                      </td>
                      <td className="text-xs text-[#666666]">
                        {item.expiryDate}
                      </td>
                      <td className="text-right space-x-1">
                        <button
                          onClick={() => updateInventoryStock(item.id, 10)}
                          className="px-2 py-1 border border-[#e5e2db] bg-white hover:border-[#1a1a1a] text-[#1a1a1a] text-xs font-semibold transition cursor-pointer"
                        >
                          +10
                        </button>
                        <button
                          onClick={() => updateInventoryStock(item.id, -5)}
                          className="px-2 py-1 border border-[#e5e2db] bg-white hover:border-[#1a1a1a] text-[#1a1a1a] text-xs font-semibold transition cursor-pointer"
                        >
                          -5
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ADD MEDICINE MODAL */}
      {isAddMedModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-2xs p-4 overflow-y-auto">
          <div className="bg-white max-w-lg w-full border border-[#e5e2db] p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#e5e2db] pb-4">
              <div>
                <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Add Stock Formulation</h3>
                <p className="text-[10px] uppercase tracking-wider text-[#666666]">Register batch SKU and safety reorder trigger</p>
              </div>
              <button onClick={() => setIsAddMedModalOpen(false)} className="text-[#666666] hover:text-[#1a1a1a] cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMedicine} className="space-y-4">
              <div className="field">
                <label>Brand / Trade Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dolo 650mg"
                  value={newMedName}
                  onChange={(e) => setNewMedName(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="field">
                <label>Generic Composition</label>
                <input
                  type="text"
                  placeholder="e.g. Paracetamol"
                  value={newMedGeneric}
                  onChange={(e) => setNewMedGeneric(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="field">
                  <label>Batch Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="BATCH-001"
                    value={newMedBatch}
                    onChange={(e) => setNewMedBatch(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Dosage Form</label>
                  <select
                    value={newMedCategory}
                    onChange={(e) => setNewMedCategory(e.target.value as any)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="Tablet">Tablet</option>
                    <option value="Capsule">Capsule</option>
                    <option value="Syrup">Syrup</option>
                    <option value="Injection">Injection</option>
                    <option value="Ointment">Ointment</option>
                    <option value="Drops">Drops</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="field">
                  <label>Initial Qty</label>
                  <input
                    type="number"
                    value={newMedQty}
                    onChange={(e) => setNewMedQty(Number(e.target.value))}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Unit Price (₹)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={newMedPrice}
                    onChange={(e) => setNewMedPrice(Number(e.target.value))}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Reorder Alert</label>
                  <input
                    type="number"
                    value={newMedReorder}
                    onChange={(e) => setNewMedReorder(Number(e.target.value))}
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="field">
                <label>Expiry Date</label>
                <input
                  type="date"
                  value={newMedExpiry}
                  onChange={(e) => setNewMedExpiry(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e5e2db]">
                <button
                  type="button"
                  onClick={() => setIsAddMedModalOpen(false)}
                  className="px-4 py-2 text-xs uppercase tracking-wider font-semibold text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-editorial"
                >
                  Save to Inventory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
