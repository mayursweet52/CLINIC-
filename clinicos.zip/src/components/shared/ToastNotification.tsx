import React from 'react';
import { useClinic } from '../../context/ClinicContext';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

export function ToastNotification() {
  const { activeToast, dismissToast } = useClinic();

  if (!activeToast) return null;

  const icons = {
    success: CheckCircle2,
    info: Info,
    warning: AlertTriangle,
    error: AlertCircle,
  };

  const Icon = icons[activeToast.type];

  const borderAccent = {
    success: 'border-l-[#4a6659] text-[#4a6659]',
    info: 'border-l-[#1a1a1a] text-[#1a1a1a]',
    warning: 'border-l-[#b27b1f] text-[#b27b1f]',
    error: 'border-l-[#a83232] text-[#a83232]',
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full animate-in fade-in slide-in-from-bottom-5 duration-200">
      <div className={`p-4 bg-white border border-[#e5e2db] border-l-4 shadow-xl flex items-start gap-3 ${borderAccent[activeToast.type]}`}>
        <Icon className="w-4 h-4 shrink-0 mt-0.5" />
        <div className="flex-1 text-xs">
          <h4 className="font-semibold text-xs text-[#1a1a1a] tracking-tight">{activeToast.title}</h4>
          <p className="mt-0.5 text-[#666666] leading-relaxed">{activeToast.message}</p>
        </div>
        <button
          onClick={dismissToast}
          className="text-[#666666] hover:text-[#1a1a1a] p-1 -mr-1 -mt-1 transition cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}
