import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Receipt, 
  Search, 
  CreditCard, 
  CheckCircle2, 
  Clock, 
  Printer, 
  FileSpreadsheet, 
  Mail, 
  DollarSign, 
  X,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { Billing, PaymentStatus } from '../../types/clinic';

export function BillingDashboard() {
  const {
    billings,
    patients,
    appointments,
    updateBillPayment,
    exportBillingToSheet,
    workspaceToken,
    showToast,
  } = useClinic();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'PAID'>('ALL');
  
  // Payment modal state
  const [selectedBillForPayment, setSelectedBillForPayment] = useState<Billing | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'UPI' | 'CASH' | 'CARD' | 'ONLINE'>('UPI');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);

  // Printable receipt view modal
  const [receiptBill, setReceiptBill] = useState<Billing | null>(null);
  const [isExportingSheet, setIsExportingSheet] = useState(false);

  // Financial KPIs
  const totalBilled = billings.reduce((sum, b) => sum + b.totalAmount, 0);
  const totalPaid = billings
    .filter((b) => b.paymentStatus === 'PAID')
    .reduce((sum, b) => sum + b.totalAmount, 0);
  const pendingCollection = billings
    .filter((b) => b.paymentStatus === 'PENDING')
    .reduce((sum, b) => sum + b.totalAmount, 0);

  const filteredBills = billings.filter((b) => {
    const matchesSearch =
      b.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || b.paymentStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Handle Payment Submit
  const handleConfirmPayment = async () => {
    if (!selectedBillForPayment) return;
    try {
      setIsProcessingPayment(true);
      await updateBillPayment(selectedBillForPayment.id, 'PAID', paymentMethod);
      setSelectedBillForPayment(null);
      showToast('Payment Settled', `Receipt recorded via ${paymentMethod}.`, 'success');
    } catch (err: any) {
      showToast('Payment Error', err?.message || 'Failed to record payment', 'error');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Export to Google Sheet
  const handleExportSheet = async () => {
    try {
      setIsExportingSheet(true);
      const url = await exportBillingToSheet();
      if (url) {
        window.open(url, '_blank');
      }
    } catch (err: any) {
      showToast('Export Error', err?.message || 'Could not export to Google Sheets', 'error');
    } finally {
      setIsExportingSheet(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="border-b border-[#e5e2db] pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
            Billing &amp; Revenue Ledger
          </h2>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            Consultation fees, pharmacy settlements &bull; Google Sheets reconciliation
          </p>
        </div>

        <button
          onClick={handleExportSheet}
          disabled={isExportingSheet}
          className="btn-editorial flex items-center gap-2 disabled:opacity-50"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          <span>{isExportingSheet ? 'Exporting...' : 'Export Ledger to Sheets'}</span>
        </button>
      </div>

      {/* Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Collected */}
        <div className="stat-block">
          <span className="stat-label">Settled Collections (INR)</span>
          <div className="stat-val mt-1">
            ₹{totalPaid.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-[#4a6659] mt-1 block">
            {billings.filter((b) => b.paymentStatus === 'PAID').length} invoices settled
          </span>
        </div>

        {/* Pending Collections */}
        <div className="stat-block">
          <span className="stat-label">Pending Receivables (INR)</span>
          <div className="stat-val mt-1 text-[#a83232]">
            ₹{pendingCollection.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-[#666666] mt-1 block">
            {billings.filter((b) => b.paymentStatus === 'PENDING').length} invoices awaiting collection
          </span>
        </div>

        {/* Total Invoiced Volume */}
        <div className="stat-block">
          <span className="stat-label">Gross Billed Turnover</span>
          <div className="stat-val mt-1">
            ₹{totalBilled.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-[#666666] mt-1 block">
            Across {billings.length} total OPD encounters
          </span>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-[#e5e2db] pb-4">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-3.5 h-3.5 text-[#666666] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search invoices by Patient Name or Invoice # (INV-2026-089)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-hairline pl-8 text-xs py-1.5"
          />
        </div>

        <div className="flex items-center gap-1 self-start sm:self-center">
          {(['ALL', 'PENDING', 'PAID'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`text-[10px] font-semibold uppercase tracking-wider px-3 py-1.5 transition cursor-pointer ${
                statusFilter === st
                  ? 'bg-[#1a1a1a] text-white'
                  : 'bg-white border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a]'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white border border-[#e5e2db] shadow-xs overflow-hidden">
        <div className="overflow-x-auto p-4 pt-2">
          <table className="queue-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Date</th>
                <th>Patient Name</th>
                <th>Consultation</th>
                <th>Pharmacy Meds</th>
                <th>Total (INR)</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredBills.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#666666] italic">
                    No matching invoices found in this view.
                  </td>
                </tr>
              ) : (
                filteredBills.map((bill) => (
                  <tr key={bill.id}>
                    <td className="font-mono text-xs font-semibold text-[#1a1a1a]">
                      {bill.invoiceNumber}
                    </td>
                    <td className="text-xs text-[#666666]">
                      {bill.createdAt.split('T')[0]}
                    </td>
                    <td className="font-semibold text-[#1a1a1a]">
                      {bill.patientName}
                    </td>
                    <td className="text-xs text-[#666666]">
                      ₹{bill.consultationFee}
                    </td>
                    <td className="text-xs text-[#666666]">
                      ₹{bill.medicineCharges}
                    </td>
                    <td className="font-semibold text-xs text-[#1a1a1a]">
                      ₹{bill.totalAmount}
                    </td>
                    <td>
                      <span className={`text-[10px] font-bold uppercase tracking-wider ${
                        bill.paymentStatus === 'PAID'
                          ? 'text-[#4a6659]'
                          : 'text-[#a83232]'
                      }`}>
                        {bill.paymentStatus} {bill.paymentMethod ? `(${bill.paymentMethod})` : ''}
                      </span>
                    </td>
                    <td className="text-right space-x-2 whitespace-nowrap">
                      {bill.paymentStatus === 'PENDING' && (
                        <button
                          onClick={() => setSelectedBillForPayment(bill)}
                          className="btn-editorial text-xs py-1 px-2.5"
                        >
                          Collect ₹{bill.totalAmount}
                        </button>
                      )}
                      <button
                        onClick={() => setReceiptBill(bill)}
                        className="p-1.5 border border-[#e5e2db] bg-white text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition cursor-pointer"
                        title="Print / View Invoice Receipt"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* COLLECT PAYMENT MODAL */}
      {selectedBillForPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-2xs p-4 overflow-y-auto">
          <div className="bg-white max-w-md w-full border border-[#e5e2db] p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#e5e2db] pb-4">
              <div>
                <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Collect Payment</h3>
                <p className="text-[10px] uppercase tracking-wider text-[#666666]">Invoice: {selectedBillForPayment.invoiceNumber}</p>
              </div>
              <button
                onClick={() => setSelectedBillForPayment(null)}
                className="text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-4 border border-[#e5e2db] bg-[#f8f7f4] space-y-2 text-xs">
                <div className="flex justify-between text-[#666666]">
                  <span>Patient:</span>
                  <span className="font-semibold text-[#1a1a1a]">{selectedBillForPayment.patientName}</span>
                </div>
                <div className="flex justify-between text-[#666666]">
                  <span>Doctor Consultation:</span>
                  <span>₹{selectedBillForPayment.consultationFee}</span>
                </div>
                <div className="flex justify-between text-[#666666]">
                  <span>Pharmacy Medications:</span>
                  <span>₹{selectedBillForPayment.medicineCharges}</span>
                </div>
                <div className="border-t border-[#e5e2db] pt-2 flex justify-between font-semibold text-sm text-[#1a1a1a]">
                  <span>Total Amount Due:</span>
                  <span className="text-[#4a6659]">₹{selectedBillForPayment.totalAmount}</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <label className="stat-label block mb-2">
                  Select Settlement Method
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['UPI', 'CASH', 'CARD', 'ONLINE'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`p-3 border text-xs font-semibold uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2 ${
                        paymentMethod === method
                          ? 'border-[#1a1a1a] bg-[#1a1a1a] text-white'
                          : 'border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#666666]'
                      }`}
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>{method}</span>
                    </button>
                  ))}
                </div>
              </div>

              {paymentMethod === 'UPI' && (
                <div className="p-3 border border-[#e5e2db] bg-[#f8f7f4] text-center text-xs text-[#1a1a1a]">
                  <span className="text-[#666666]">Dynamic Clinic UPI VPA: </span>
                  <strong className="font-mono">apexmetro@upi</strong>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e5e2db]">
                <button
                  type="button"
                  onClick={() => setSelectedBillForPayment(null)}
                  className="px-4 py-2 text-xs uppercase tracking-wider font-semibold text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmPayment}
                  disabled={isProcessingPayment}
                  className="btn-editorial disabled:opacity-50"
                >
                  {isProcessingPayment ? 'Recording...' : `Record Payment (₹${selectedBillForPayment.totalAmount})`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRINTABLE RECEIPT / INVOICE MODAL */}
      {receiptBill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-2xs p-4 overflow-y-auto">
          <div className="bg-white max-w-xl w-full border border-[#e5e2db] shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-[#e5e2db] bg-[#f8f7f4] flex items-center justify-between no-print">
              <span className="font-semibold text-xs uppercase tracking-wider text-[#1a1a1a]">Official Tax Invoice &bull; Receipt</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="btn-editorial text-xs py-1 px-3 flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" /> Print Receipt
                </button>
                <button onClick={() => setReceiptBill(null)} className="text-[#666666] hover:text-[#1a1a1a] p-1 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="p-8 sm:p-10 space-y-6 text-[#1a1a1a]" id="printable-receipt">
              {/* Clinic Branding */}
              <div className="border-b border-[#e5e2db] pb-5 flex justify-between items-start">
                <div>
                  <h1 className="font-cormorant text-2xl font-bold text-[#1a1a1a] tracking-tight">APEX METRO CLINIC</h1>
                  <p className="text-xs text-[#666666] mt-0.5">Multi-Specialty OPD &amp; Diagnostic Center</p>
                  <p className="text-xs text-[#666666]">Healthcare Towers, Prabhadevi, Mumbai 400025</p>
                  <p className="text-[11px] text-[#666666]">GSTIN: 27AABCA1234F1Z5 &bull; Tel: +91 22 2430 8900</p>
                </div>
                <div className="text-right">
                  <div className="stat-label">Tax Invoice</div>
                  <div className="font-mono font-bold text-xs text-[#4a6659] mt-0.5">{receiptBill.invoiceNumber}</div>
                  <div className="text-xs text-[#666666] mt-0.5">Date: {receiptBill.createdAt.split('T')[0]}</div>
                </div>
              </div>

              {/* Bill To */}
              <div className="grid grid-cols-2 text-xs">
                <div>
                  <span className="stat-label">Patient Name</span>
                  <span className="font-semibold text-[#1a1a1a] text-sm block mt-0.5">{receiptBill.patientName}</span>
                </div>
                <div className="text-right">
                  <span className="stat-label">Payment Status</span>
                  <span className="font-semibold text-xs uppercase tracking-wider text-[#4a6659] block mt-0.5">{receiptBill.paymentStatus}</span>
                  {receiptBill.paymentMethod && (
                    <span className="block text-[#666666] text-[11px]">Via {receiptBill.paymentMethod}</span>
                  )}
                </div>
              </div>

              {/* Line Items Table */}
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#e5e2db] font-semibold text-[#666666] uppercase text-[10px] tracking-wider">
                    <th className="py-2.5">Item Description</th>
                    <th className="py-2.5 text-right">Amount (INR)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#e5e2db]">
                  <tr>
                    <td className="py-3">
                      <div className="font-semibold text-[#1a1a1a]">Doctor OPD Consultation Fee</div>
                      <div className="text-[#666666] text-[11px]">Standard Specialist Review</div>
                    </td>
                    <td className="py-3 text-right font-medium">₹{receiptBill.consultationFee.toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td className="py-3">
                      <div className="font-semibold text-[#1a1a1a]">Pharmacy &amp; Prescribed Medication Charges</div>
                      <div className="text-[#666666] text-[11px]">Dispensed by clinic dispensary</div>
                    </td>
                    <td className="py-3 text-right font-medium">₹{receiptBill.medicineCharges.toFixed(2)}</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-[#1a1a1a] text-sm font-semibold">
                    <td className="py-3">Total Amount Due</td>
                    <td className="py-3 text-right text-[#4a6659]">₹{receiptBill.totalAmount.toFixed(2)}</td>
                  </tr>
                </tfoot>
              </table>

              <div className="border-t border-[#e5e2db] pt-5 text-center text-xs text-[#666666]">
                <p>Thank you for placing your trust in Apex Metro Clinic.</p>
                <p className="text-[10px] text-[#666666] mt-1">Computer generated invoice &bull; No signature required</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
