import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Calendar, 
  FileSpreadsheet, 
  Mail, 
  Users, 
  CheckCircle2, 
  ExternalLink, 
  RefreshCw, 
  LogOut,
  ShieldCheck,
  X 
} from 'lucide-react';

interface WorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WorkspaceModal({ isOpen, onClose }: WorkspaceModalProps) {
  const { 
    workspaceToken, 
    connectGoogleWorkspace, 
    disconnectGoogleWorkspace, 
    exportAppointmentsToSheet,
    exportBillingToSheet,
    exportPatientsToSheet,
    showToast 
  } = useClinic();

  const [isExporting, setIsExporting] = useState<string | null>(null);
  const [isAuthorizing, setIsAuthorizing] = useState(false);
  const [lastSheetUrl, setLastSheetUrl] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = async () => {
    setIsAuthorizing(true);
    try {
      await connectGoogleWorkspace();
    } finally {
      setIsAuthorizing(false);
    }
  };

  const handleExport = async (type: 'appts' | 'billing' | 'patients') => {
    try {
      setIsExporting(type);
      let url: string | null = '';
      if (type === 'appts') url = await exportAppointmentsToSheet();
      else if (type === 'billing') url = await exportBillingToSheet();
      else if (type === 'patients') url = await exportPatientsToSheet();
      if (url) setLastSheetUrl(url);
    } catch (err: any) {
      showToast('Export Error', err?.message || 'Failed to export', 'error');
    } finally {
      setIsExporting(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-2xs p-4 overflow-y-auto">
      <div className="bg-white max-w-2xl w-full border border-[#e5e2db] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-6 sm:p-8 border-b border-[#e5e2db] bg-[#f8f7f4] relative">
          <button 
            onClick={onClose} 
            className="absolute top-6 right-6 text-[#666666] hover:text-[#1a1a1a] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#4a6659]">
              Cloud Integrations
            </span>
            <h2 className="font-cormorant text-3xl font-semibold text-[#1a1a1a]">
              Google Workspace Cloud Suite
            </h2>
            <p className="text-xs text-[#666666] max-w-lg mt-1 font-normal">
              Direct synchronization with Google Calendar, Sheets, Gmail, and Google Contacts for seamless clinic operations.
            </p>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Connection status banner */}
          <div className="stat-block flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="pulse" />
                <p className="font-cormorant text-xl font-semibold text-[#1a1a1a]">
                  {workspaceToken ? 'Google Workspace Connected' : 'Google Workspace Link Required'}
                </p>
              </div>
              <p className="text-xs text-[#666666] mt-0.5">
                {workspaceToken 
                  ? 'Authorized for Calendar, Sheets, Gmail & Google Contacts' 
                  : 'Connect your clinic Google account to activate real-time sync & exports.'}
              </p>
            </div>

            {workspaceToken ? (
              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  onClick={handleConnect}
                  disabled={isAuthorizing}
                  className="text-xs font-semibold px-3 py-1.5 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition disabled:opacity-50 flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAuthorizing ? 'animate-spin' : ''}`} />
                  <span>{isAuthorizing ? 'Authorizing...' : 'Re-link'}</span>
                </button>
                <button
                  onClick={disconnectGoogleWorkspace}
                  className="text-xs font-semibold px-3 py-1.5 border border-[#e5e2db] bg-white text-[#a83232] hover:border-[#a83232] transition flex items-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Disconnect</span>
                </button>
              </div>
            ) : (
              <button
                onClick={handleConnect}
                disabled={isAuthorizing}
                className="btn-editorial flex items-center gap-2 self-start sm:self-center disabled:opacity-60 cursor-pointer"
              >
                {isAuthorizing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Connecting...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                    <span>Sign in with Google</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* 4 Workspace Tools Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Google Calendar */}
            <div className="p-4 border border-[#e5e2db] bg-white">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 font-medium text-sm text-[#1a1a1a]">
                  <Calendar className="w-4 h-4 text-[#4a6659]" />
                  <span>Google Calendar</span>
                </div>
                {workspaceToken ? (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">Active</span>
                ) : (
                  <span className="text-[10px] uppercase tracking-wider text-[#666666]">Standby</span>
                )}
              </div>
              <p className="text-xs text-[#666666] leading-relaxed">
                Syncs patient visits onto clinic calendars with doctor assignments and token numbers.
              </p>
            </div>

            {/* Google Sheets */}
            <div className="p-4 border border-[#e5e2db] bg-white">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 font-medium text-sm text-[#1a1a1a]">
                  <FileSpreadsheet className="w-4 h-4 text-[#4a6659]" />
                  <span>Google Sheets</span>
                </div>
                {workspaceToken ? (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">Active</span>
                ) : (
                  <span className="text-[10px] uppercase tracking-wider text-[#666666]">Standby</span>
                )}
              </div>
              <p className="text-xs text-[#666666] leading-relaxed">
                Exports appointment audit logs, revenue ledgers, and directory records directly into spreadsheets.
              </p>
            </div>

            {/* Gmail */}
            <div className="p-4 border border-[#e5e2db] bg-white">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 font-medium text-sm text-[#1a1a1a]">
                  <Mail className="w-4 h-4 text-[#4a6659]" />
                  <span>Gmail Dispatches</span>
                </div>
                {workspaceToken ? (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">Active</span>
                ) : (
                  <span className="text-[10px] uppercase tracking-wider text-[#666666]">Standby</span>
                )}
              </div>
              <p className="text-xs text-[#666666] leading-relaxed">
                Sends booking confirmations and digital prescription receipts straight to patients.
              </p>
            </div>

            {/* Google Contacts */}
            <div className="p-4 border border-[#e5e2db] bg-white">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 font-medium text-sm text-[#1a1a1a]">
                  <Users className="w-4 h-4 text-[#4a6659]" />
                  <span>Google Contacts</span>
                </div>
                {workspaceToken ? (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">Active</span>
                ) : (
                  <span className="text-[10px] uppercase tracking-wider text-[#666666]">Standby</span>
                )}
              </div>
              <p className="text-xs text-[#666666] leading-relaxed">
                Synchronizes patient phone directory with caller ID support for reception and triage desks.
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          {workspaceToken && (
            <div className="p-4 border border-[#e5e2db] bg-[#f8f7f4] space-y-3">
              <h4 className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#666666]">
                Direct Cloud Exports
              </h4>
              <div className="flex flex-wrap gap-2">
                <button
                  disabled={isExporting !== null}
                  onClick={() => handleExport('appts')}
                  className="text-xs px-3 py-1.5 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition font-medium disabled:opacity-50 cursor-pointer"
                >
                  {isExporting === 'appts' ? 'Exporting...' : 'Export Appointments Sheet'}
                </button>
                <button
                  disabled={isExporting !== null}
                  onClick={() => handleExport('billing')}
                  className="text-xs px-3 py-1.5 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition font-medium disabled:opacity-50 cursor-pointer"
                >
                  {isExporting === 'billing' ? 'Exporting...' : 'Export Billing Ledger'}
                </button>
                <button
                  disabled={isExporting !== null}
                  onClick={() => handleExport('patients')}
                  className="text-xs px-3 py-1.5 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition font-medium disabled:opacity-50 cursor-pointer"
                >
                  {isExporting === 'patients' ? 'Exporting...' : 'Export Patient Master'}
                </button>
              </div>

              {lastSheetUrl && (
                <div className="mt-3 p-3 bg-white border border-[#4a6659] flex items-center justify-between text-xs text-[#1a1a1a]">
                  <span>Spreadsheet generated in Google Drive</span>
                  <a
                    href={lastSheetUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-[#4a6659] hover:underline flex items-center gap-1"
                  >
                    Open Sheet <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-6 bg-[#f8f7f4] border-t border-[#e5e2db] flex items-center justify-between">
          <p className="text-[11px] text-[#666666]">
            OAuth 2.0 Security &bull; Scoped Client Permission Model
          </p>
          <button
            onClick={onClose}
            className="btn-editorial text-[10px] py-2 px-4 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
