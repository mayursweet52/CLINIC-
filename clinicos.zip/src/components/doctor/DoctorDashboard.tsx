import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Stethoscope, 
  Clock, 
  Activity, 
  Sparkles, 
  BrainCircuit, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  Calendar, 
  Mail, 
  Plus, 
  Trash2, 
  UserCheck, 
  CalendarOff,
  FileText,
  Search
} from 'lucide-react';
import { 
  HealthAppointment, 
  MedicineItem 
} from '../../types/clinic';
import { 
  expandMedicalShorthand, 
  fastSymptomTriage, 
  complexDifferentialDiagnosis 
} from '../../lib/gemini';

export function DoctorDashboard() {
  const {
    doctors,
    appointments,
    patients,
    inventory,
    startConsultation,
    completeConsultation,
    syncToCalendar,
    sendAppointmentConfirmationEmail,
    markDoctorLeave,
    showToast,
  } = useClinic();

  // Active doctor selector
  const [activeDoctorId, setActiveDoctorId] = useState<string>(doctors[0]?.id || 'doc-001');
  const currentDoctor = doctors.find((d) => d.id === activeDoctorId) || doctors[0];

  // Active tabs
  const [activeTab, setActiveTab] = useState<'queue' | 'leave'>('queue');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ARRIVED' | 'IN_CONSULTATION' | 'SCHEDULED' | 'COMPLETED'>('ALL');
  
  // Active consultation patient
  const [activeAppointment, setActiveAppointment] = useState<HealthAppointment | null>(null);

  // Consultation Room Form State
  const [diagnosis, setDiagnosis] = useState('');
  const [symptomsInput, setSymptomsInput] = useState('');
  const [advice, setAdvice] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [syncCalendar, setSyncCalendar] = useState(true);
  const [sendEmail, setSendEmail] = useState(true);

  // Vitals
  const [bp, setBp] = useState('120/80');
  const [pulse, setPulse] = useState('74');
  const [temp, setTemp] = useState('98.6');
  const [spo2, setSpo2] = useState('99');
  const [weight, setWeight] = useState('68');

  // Prescribed Medicines list
  const [prescribedMeds, setPrescribedMeds] = useState<MedicineItem[]>([]);
  const [selectedInventoryId, setSelectedInventoryId] = useState('');
  const [medDosage, setMedDosage] = useState('1 tablet');
  const [medFrequency, setMedFrequency] = useState('1-0-1 (Twice daily)');
  const [medDuration, setMedDuration] = useState('5 days');
  const [medInstructions, setMedInstructions] = useState('After meals');

  // AI Assistant drawer/state
  const [aiPanelOpen, setAiPanelOpen] = useState(false);
  const [shorthandInput, setShorthandInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiOutput, setAiOutput] = useState<{ mode: 'flash' | 'thinking'; content: string } | null>(null);

  // Leave modal state
  const [leaveDate, setLeaveDate] = useState('');
  const [leaveReason, setLeaveReason] = useState('Medical conference');
  const [isSubmittingLeave, setIsSubmittingLeave] = useState(false);

  // Doctor's appointments
  const doctorAppointments = appointments.filter((a) => a.doctorId === activeDoctorId);
  const filteredAppointments = doctorAppointments.filter((a) => {
    if (statusFilter === 'ALL') return true;
    return a.status === statusFilter;
  });

  const arrivedCount = doctorAppointments.filter((a) => a.status === 'ARRIVED').length;
  const inConsultCount = doctorAppointments.filter((a) => a.status === 'IN_CONSULTATION').length;
  const completedCount = doctorAppointments.filter((a) => a.status === 'COMPLETED').length;

  const currentPatient = activeAppointment
    ? patients.find((p) => p.id === activeAppointment.patientId)
    : null;

  // Open consultation room for an appointment
  const handleOpenConsultation = (appt: HealthAppointment) => {
    setActiveAppointment(appt);
    if (appt.status === 'ARRIVED' || appt.status === 'SCHEDULED') {
      startConsultation(appt.id);
    }
    setDiagnosis('');
    setSymptomsInput(appt.reason || '');
    setAdvice('Drink plenty of fluids, rest adequately, and follow dosage timing.');
    setPrescribedMeds([]);
    setAiOutput(null);
  };

  // Add medicine to prescription
  const handleAddMedicine = () => {
    const invItem = inventory.find((i) => i.id === selectedInventoryId);
    if (!invItem) {
      showToast('Select Medicine', 'Please choose a medicine from clinic inventory.', 'warning');
      return;
    }

    const newItem: MedicineItem = {
      id: `med-${Date.now()}`,
      medicineName: invItem.medicineName,
      dosage: medDosage,
      frequency: medFrequency,
      duration: medDuration,
      instructions: medInstructions,
      quantity: 10,
      unitPrice: invItem.unitPrice,
    };

    setPrescribedMeds((prev) => [...prev, newItem]);
    setSelectedInventoryId('');
  };

  const handleRemoveMedicine = (id: string) => {
    setPrescribedMeds((prev) => prev.filter((m) => m.id !== id));
  };

  // AI Handler: Low-latency Shorthand Expander
  const handleExpandShorthand = async () => {
    if (!shorthandInput.trim()) return;
    try {
      setAiLoading(true);
      const expanded = await expandMedicalShorthand(shorthandInput);
      setAiOutput({ mode: 'flash', content: expanded });
    } catch {
      showToast('AI Error', 'Could not expand shorthand.', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  // AI Handler: Low-latency Fast Triage
  const handleFastTriage = async () => {
    if (!symptomsInput.trim()) {
      showToast('Symptoms Missing', 'Enter symptoms to triage.', 'warning');
      return;
    }
    try {
      setAiLoading(true);
      const triage = await fastSymptomTriage({
        symptoms: symptomsInput,
        age: currentPatient?.age || 35,
        gender: currentPatient?.gender || 'MALE',
        vitals: `BP: ${bp}, Pulse: ${pulse}, Temp: ${temp}F, SpO2: ${spo2}%`,
      });
      const formatted = `TRIAGE LEVEL: ${triage.triageLevel}\n\nPOSSIBLE CONDITIONS:\n${triage.possibleConditions.map((c) => `• ${c}`).join('\n')}\n\nIMMEDIATE RECOMMENDATIONS:\n${triage.immediateRecommendations}`;
      setAiOutput({ mode: 'flash', content: formatted });
    } catch {
      showToast('AI Error', 'Triage service unavailable.', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  // AI Handler: High Thinking Deep Reasoning
  const handleHighThinkingAnalysis = async () => {
    if (!currentPatient) return;
    try {
      setAiLoading(true);
      const deepAnalysis = await complexDifferentialDiagnosis({
        patientAge: currentPatient.age,
        gender: currentPatient.gender,
        chiefComplaint: symptomsInput || currentPatient.chronicConditions.join(', ') || 'Routine OPD Evaluation',
        duration: 'Acute / Subacute presentation',
        historyOfPresentIllness: `Diagnosis under consideration: ${diagnosis || 'Unspecified'}. Additional physician observations: ${advice || 'None noted'}`,
        chronicConditions: currentPatient.chronicConditions || [],
        currentMedications: [],
        allergies: currentPatient.allergies || [],
        vitals: {
          bloodPressure: bp,
          pulse: `${pulse} bpm`,
          temperature: `${temp} F`,
          spo2: `${spo2}%`,
          weight: `${weight} kg`,
        },
      });
      setAiOutput({ mode: 'thinking', content: deepAnalysis });
    } catch {
      showToast('AI Error', 'High thinking analysis failed.', 'error');
    } finally {
      setAiLoading(false);
    }
  };

  // Complete Consultation
  const handleCompleteConsultation = async () => {
    if (!activeAppointment) return;

    if (!diagnosis.trim()) {
      showToast('Diagnosis Required', 'Please enter a clinical diagnosis.', 'warning');
      return;
    }

    try {
      await completeConsultation({
        appointmentId: activeAppointment.id,
        diagnosis,
        symptoms: symptomsInput ? symptomsInput.split(',').map((s) => s.trim()) : [],
        vitals: {
          bp,
          pulse: String(pulse || '72'),
          temp: String(temp || '98.6'),
          spo2: String(spo2 || '98'),
          weight: String(weight || '70'),
        },
        medicines: prescribedMeds,
        advice,
        followUpDate: followUpDate || undefined,
        consultationFee: currentDoctor.consultationFee,
        syncCalendar,
        sendEmail,
      });

      setActiveAppointment(null);
      showToast('Consultation Saved', 'Record archived and sent to Pharmacy & Billing.', 'success');
    } catch (err: any) {
      showToast('Save Error', err?.message || 'Failed to complete visit', 'error');
    }
  };

  // Submit Doctor Leave
  const handleMarkLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveDate) return;

    try {
      setIsSubmittingLeave(true);
      await markDoctorLeave(activeDoctorId, leaveDate, leaveReason);
      setLeaveDate('');
      showToast('Leave Registered', `Leave recorded for ${currentDoctor.name}. Conflicts handled.`, 'info');
    } catch (err: any) {
      showToast('Leave Error', err?.message, 'error');
    } finally {
      setIsSubmittingLeave(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Doctor Header Banner */}
      <div className="border-b border-[#e5e2db] pb-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-4">
            <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
              {currentDoctor.name}
            </h2>
            <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 border border-[#e5e2db] bg-white text-[#4a6659]">
              {currentDoctor.roomNumber}
            </span>
          </div>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            {currentDoctor.specialty} &bull; {currentDoctor.qualification} &bull; OPD Fee: ₹{currentDoctor.consultationFee}
          </p>
        </div>

        {/* Doctor Switcher & Metrics */}
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={activeDoctorId}
            onChange={(e) => {
              setActiveDoctorId(e.target.value);
              setActiveAppointment(null);
            }}
            className="text-xs py-2 px-3 border border-[#e5e2db] bg-white text-[#1a1a1a] focus:outline-hidden focus:border-[#4a6659] font-medium cursor-pointer"
          >
            {doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.department})
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2">
            <div className="stat-block py-2 px-3 text-center min-w-[75px]">
              <span className="stat-val text-lg block">{arrivedCount}</span>
              <span className="stat-label text-[9px]">Waiting</span>
            </div>
            <div className="stat-block py-2 px-3 text-center min-w-[75px]">
              <span className="stat-val text-lg block">{inConsultCount}</span>
              <span className="stat-label text-[9px]">In Room</span>
            </div>
            <div className="stat-block py-2 px-3 text-center min-w-[75px]">
              <span className="stat-val text-lg block">{completedCount}</span>
              <span className="stat-label text-[9px]">Done</span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e5e2db]">
        <div className="flex items-center gap-8">
          <button
            onClick={() => {
              setActiveTab('queue');
              setActiveAppointment(null);
            }}
            className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
              activeTab === 'queue'
                ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
                : 'text-[#666666] hover:text-[#1a1a1a]'
            }`}
          >
            Today's OPD Queue ({doctorAppointments.length})
          </button>
          <button
            onClick={() => {
              setActiveTab('leave');
              setActiveAppointment(null);
            }}
            className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
              activeTab === 'leave'
                ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
                : 'text-[#666666] hover:text-[#1a1a1a]'
            }`}
          >
            Leave &amp; Schedule Out
          </button>
        </div>

        {activeTab === 'queue' && (
          <div className="flex items-center gap-1 pb-2 overflow-x-auto">
            {(['ALL', 'ARRIVED', 'IN_CONSULTATION', 'COMPLETED'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 transition cursor-pointer ${
                  statusFilter === st
                    ? 'bg-[#1a1a1a] text-white'
                    : 'text-[#666666] hover:text-[#1a1a1a] bg-white border border-[#e5e2db]'
                }`}
              >
                {st.replace('_', ' ')}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* TAB 1: OPD Queue List */}
      {activeTab === 'queue' && !activeAppointment && (
        <div className="bg-white border border-[#e5e2db] shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e5e2db] bg-[#f8f7f4] flex items-center justify-between">
            <h3 className="text-xs uppercase tracking-wider font-semibold text-[#1a1a1a]">
              Live Queue &bull; {currentDoctor.department} ({filteredAppointments.length} patients)
            </h3>
            <span className="text-[11px] text-[#666666]">
              Select patient to open active consultation desk
            </span>
          </div>

          {filteredAppointments.length === 0 ? (
            <div className="p-12 text-center text-[#666666]">
              <UserCheck className="w-8 h-8 mx-auto text-[#666666] mb-2 opacity-50" />
              <p className="font-semibold text-xs text-[#1a1a1a]">No patients in this queue view</p>
              <p className="text-xs text-[#666666] mt-1">Select another filter or await lobby check-in.</p>
            </div>
          ) : (
            <div className="divide-y divide-[#e5e2db]">
              {filteredAppointments.map((appt) => {
                const pat = patients.find((p) => p.id === appt.patientId);
                const hasAllergy = (pat?.allergies && pat.allergies.length > 0);

                return (
                  <div
                    key={appt.id}
                    className="p-4 sm:p-5 hover:bg-[#f8f7f4] transition flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-4">
                      {/* Token circle */}
                      <div className="token-circle text-base w-12 h-12">
                        {appt.tokenNumber}
                      </div>

                      {/* Patient & Reason info */}
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold text-[#1a1a1a] text-sm">{appt.patientName}</h4>
                          <span className="text-xs text-[#666666]">
                            {appt.patientAge || pat?.age} yrs &bull; {appt.patientGender || pat?.gender}
                          </span>
                          {hasAllergy && (
                            <span className="px-2 py-0.5 text-[10px] font-semibold border border-[#e5e2db] text-[#a83232] bg-white flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3 text-[#a83232]" /> Allergies: {pat?.allergies.join(', ')}
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-[#666666] mt-1">
                          <strong className="text-[#1a1a1a]">Chief Complaint:</strong> {appt.reason || 'OPD Consultation'}
                        </p>

                        <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[#666666]">
                          <span>Slot: {appt.appointmentTime}</span>
                          {appt.checkedInAt && <span>&bull; Checked In: {appt.checkedInAt}</span>}
                          {appt.consultationStartedAt && <span>&bull; In Chamber: {appt.consultationStartedAt}</span>}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-3 self-end sm:self-center">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-[#4a6659]">
                        {appt.status.replace('_', ' ')}
                      </span>

                      {appt.status !== 'COMPLETED' ? (
                        <button
                          onClick={() => handleOpenConsultation(appt)}
                          className="btn-editorial text-[11px] py-1.5 px-3 flex items-center gap-1.5"
                        >
                          <Stethoscope className="w-3.5 h-3.5" />
                          <span>{appt.status === 'IN_CONSULTATION' ? 'Resume Visit' : 'Start Visit'}</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => handleOpenConsultation(appt)}
                          className="text-xs font-semibold px-3 py-1.5 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition flex items-center gap-1 cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" /> Review Case
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ACTIVE CONSULTATION ROOM WORKSTATION */}
      {activeAppointment && currentPatient && (
        <div className="bg-white border border-[#e5e2db] shadow-xs overflow-hidden space-y-6">
          {/* Workstation Header */}
          <div className="p-6 border-b border-[#e5e2db] bg-[#f8f7f4] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="token-circle text-lg w-12 h-12">
                {activeAppointment.tokenNumber}
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">{currentPatient.name}</h3>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-[#e5e2db] bg-white text-[#666666]">
                    {currentPatient.patientCode}
                  </span>
                </div>
                <p className="text-xs text-[#666666] mt-0.5">
                  {currentPatient.age} yrs &bull; {currentPatient.gender} &bull; Blood: <strong>{currentPatient.bloodGroup}</strong> &bull; Phone: {currentPatient.phone}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setAiPanelOpen(!aiPanelOpen)}
                className={`px-3 py-1.5 text-xs uppercase tracking-wider font-semibold transition border cursor-pointer flex items-center gap-1.5 ${
                  aiPanelOpen
                    ? 'bg-[#1a1a1a] text-white border-[#1a1a1a]'
                    : 'bg-white text-[#1a1a1a] border-[#e5e2db] hover:border-[#1a1a1a]'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#4a6659]" />
                <span>AI Clinical Assistant</span>
              </button>
              <button
                onClick={() => setActiveAppointment(null)}
                className="px-3 py-1.5 text-xs uppercase tracking-wider font-semibold border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] bg-white transition cursor-pointer"
              >
                Close Station
              </button>
            </div>
          </div>

          {/* Critical Clinical Alerts */}
          {(currentPatient.allergies.length > 0 || currentPatient.chronicConditions.length > 0) && (
            <div className="p-3 px-6 bg-[#f8f7f4] border-b border-[#e5e2db] flex flex-wrap items-center gap-4 text-xs">
              {currentPatient.allergies.length > 0 && (
                <div className="flex items-center gap-1.5 text-[#a83232] font-semibold">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>KNOWN ALLERGIES:</span>
                  <span className="underline">{currentPatient.allergies.join(', ')}</span>
                </div>
              )}
              {currentPatient.chronicConditions.length > 0 && (
                <div className="flex items-center gap-1.5 text-[#1a1a1a]">
                  <span className="font-semibold text-[#666666]">CHRONIC CONDITIONS:</span>
                  <span>{currentPatient.chronicConditions.join(', ')}</span>
                </div>
              )}
            </div>
          )}

          {/* AI Clinical Assistant Slideout/Drawer */}
          {aiPanelOpen && (
            <div className="p-6 border-b border-[#e5e2db] bg-[#f8f7f4] space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#4a6659]" />
                  <h4 className="font-cormorant text-xl font-semibold text-[#1a1a1a]">
                    AI Clinical Decision Support
                  </h4>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border border-[#e5e2db] bg-white text-[#4a6659]">
                    Dual Mode: Flash-Lite + High Thinking
                  </span>
                </div>
                <button
                  onClick={() => setAiPanelOpen(false)}
                  className="text-xs text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
                >
                  Hide &times;
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Low-latency Flash-Lite Expander & Triage */}
                <div className="bg-white p-5 border border-[#e5e2db] space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1a1a1a]">
                    <Zap className="w-3.5 h-3.5 text-[#4a6659]" />
                    <span>Low-Latency Shorthand &amp; Triage (gemini-3.1-flash-lite)</span>
                  </div>
                  <p className="text-xs text-[#666666]">
                    Type doctor's shorthand prescription to expand into standard patient directions in &lt;1 second.
                  </p>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. tab pcm 650 tid pc x 3d, cap pan 40 od ac"
                      value={shorthandInput}
                      onChange={(e) => setShorthandInput(e.target.value)}
                      className="input-hairline flex-1 text-xs"
                    />
                    <button
                      disabled={aiLoading}
                      onClick={handleExpandShorthand}
                      className="btn-editorial text-xs px-3 py-2 disabled:opacity-50"
                    >
                      Expand
                    </button>
                  </div>

                  <button
                    disabled={aiLoading}
                    onClick={handleFastTriage}
                    className="w-full text-xs font-semibold py-2 border border-[#e5e2db] bg-white text-[#1a1a1a] hover:border-[#1a1a1a] transition cursor-pointer disabled:opacity-50"
                  >
                    Run Instant Symptom Risk Triage &lt;1s
                  </button>
                </div>

                {/* 2. High Thinking Differential Diagnosis */}
                <div className="bg-white p-5 border border-[#e5e2db] space-y-3">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1a1a1a]">
                    <BrainCircuit className="w-3.5 h-3.5 text-[#4a6659]" />
                    <span>High Thinking Deep Reasoning (gemini-3.1-pro-preview)</span>
                  </div>
                  <p className="text-xs text-[#666666]">
                    Uses high-thinking mode (thinkingLevel: HIGH) to analyze multi-morbid cases, polypharmacy interactions, and tiered diagnostic workup.
                  </p>

                  <button
                    disabled={aiLoading}
                    onClick={handleHighThinkingAnalysis}
                    className="w-full py-2.5 bg-[#1a1a1a] text-white hover:bg-black text-xs font-semibold uppercase tracking-wider transition disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <BrainCircuit className="w-3.5 h-3.5 text-[#4a6659]" />
                    <span>Generate Differential Diagnosis &amp; Drug Workup</span>
                  </button>
                </div>
              </div>

              {/* AI Output Display */}
              {aiLoading && (
                <div className="p-4 bg-white border border-[#e5e2db] text-center text-xs text-[#1a1a1a] font-medium animate-pulse flex items-center justify-center gap-2">
                  <Sparkles className="w-4 h-4 animate-spin text-[#4a6659]" />
                  <span>Clinical intelligence synthesizing medical evaluation...</span>
                </div>
              )}

              {aiOutput && !aiLoading && (
                <div className="p-5 bg-white border border-[#e5e2db] space-y-2">
                  <div className="flex items-center justify-between text-xs border-b border-[#e5e2db] pb-2">
                    <span className="font-semibold text-[#1a1a1a]">
                      {aiOutput.mode === 'thinking' ? 'Deep Clinical Differential & Case Analysis' : 'Instant Clinical Output'}
                    </span>
                    <button
                      onClick={() => setAdvice((prev) => prev ? `${prev}\n\n${aiOutput.content}` : aiOutput.content)}
                      className="text-xs text-[#4a6659] hover:underline font-semibold cursor-pointer"
                    >
                      Append to Doctor's Advice &rarr;
                    </button>
                  </div>
                  <div className="text-xs text-[#1a1a1a] font-mono whitespace-pre-wrap max-h-60 overflow-y-auto leading-relaxed">
                    {aiOutput.content}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Form Body */}
          <div className="p-6 sm:p-8 space-y-8">
            {/* Vitals row */}
            <div>
              <h4 className="form-section-label flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-[#4a6659]" />
                <span>Patient Vitals Entry</span>
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
                <div className="field">
                  <label>BP (mmHg)</label>
                  <input
                    type="text"
                    value={bp}
                    onChange={(e) => setBp(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Pulse (bpm)</label>
                  <input
                    type="text"
                    value={pulse}
                    onChange={(e) => setPulse(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Temp (°F)</label>
                  <input
                    type="text"
                    value={temp}
                    onChange={(e) => setTemp(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>SpO2 (%)</label>
                  <input
                    type="text"
                    value={spo2}
                    onChange={(e) => setSpo2(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Weight (kg)</label>
                  <input
                    type="text"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    className="input-hairline"
                  />
                </div>
              </div>
            </div>

            {/* Diagnosis & Symptoms */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="field">
                <label>Primary Clinical Diagnosis *</label>
                <input
                  type="text"
                  placeholder="e.g. Acute Bronchitis / Essential Hypertension"
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  className="input-hairline"
                  required
                />
              </div>
              <div className="field">
                <label>Chief Complaints &amp; Symptoms</label>
                <input
                  type="text"
                  placeholder="e.g. Dry cough x 4 days, low-grade fever"
                  value={symptomsInput}
                  onChange={(e) => setSymptomsInput(e.target.value)}
                  className="input-hairline"
                />
              </div>
            </div>

            {/* E-Prescription Builder */}
            <div className="border border-[#e5e2db] p-5 bg-[#f8f7f4] space-y-4">
              <div className="flex items-center justify-between border-b border-[#e5e2db] pb-3">
                <h4 className="form-section-label mb-0 flex items-center gap-1.5">
                  <Stethoscope className="w-3.5 h-3.5 text-[#4a6659]" />
                  <span>Prescription &amp; Pharmacy Dispensary</span>
                </h4>
                <span className="text-[11px] text-[#666666]">
                  Select from active inventory
                </span>
              </div>

              {/* Add medicine row */}
              <div className="grid grid-cols-1 sm:grid-cols-6 gap-3 bg-white p-4 border border-[#e5e2db]">
                <div className="sm:col-span-2 field">
                  <label>Medicine (Stock)</label>
                  <select
                    value={selectedInventoryId}
                    onChange={(e) => setSelectedInventoryId(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="">-- Choose Medicine --</option>
                    {inventory.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.medicineName} ({item.quantity} in stock - ₹{item.unitPrice})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>Dosage</label>
                  <input
                    type="text"
                    value={medDosage}
                    onChange={(e) => setMedDosage(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Frequency</label>
                  <input
                    type="text"
                    value={medFrequency}
                    onChange={(e) => setMedFrequency(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Duration</label>
                  <input
                    type="text"
                    value={medDuration}
                    onChange={(e) => setMedDuration(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={handleAddMedicine}
                    className="btn-editorial w-full py-2.5 text-xs flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                </div>
              </div>

              {/* Added medicines list */}
              {prescribedMeds.length > 0 && (
                <div className="bg-white border border-[#e5e2db] divide-y divide-[#e5e2db]">
                  {prescribedMeds.map((med, index) => (
                    <div key={med.id} className="p-3 px-4 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-semibold text-[#1a1a1a] mr-2">
                          {index + 1}. {med.medicineName}
                        </span>
                        <span className="text-[#666666]">
                          {med.dosage} &bull; {med.frequency} &bull; {med.duration}
                        </span>
                        <span className="text-[#666666] block text-[11px] mt-0.5">
                          {med.instructions}
                        </span>
                      </div>
                      <button
                        onClick={() => handleRemoveMedicine(med.id)}
                        className="text-[#a83232] hover:underline p-1 cursor-pointer"
                        title="Remove medication"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Advice & Follow-up */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 field">
                <label>Doctor's Advice &amp; Patient Instructions</label>
                <textarea
                  rows={3}
                  value={advice}
                  onChange={(e) => setAdvice(e.target.value)}
                  className="input-hairline"
                />
              </div>
              <div className="space-y-4">
                <div className="field">
                  <label>Follow-up Review Date</label>
                  <input
                    type="date"
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="input-hairline"
                  />
                </div>

                {/* Workspace check options */}
                <div className="space-y-2 text-xs text-[#666666] pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={syncCalendar}
                      onChange={(e) => setSyncCalendar(e.target.checked)}
                      className="accent-[#4a6659]"
                    />
                    <span>Sync follow-up to Google Calendar</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={sendEmail}
                      onChange={(e) => setSendEmail(e.target.checked)}
                      className="accent-[#4a6659]"
                    />
                    <span>Dispatch Rx via Gmail</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Workstation Footer Actions */}
          <div className="p-4 sm:p-6 bg-[#f8f7f4] border-t border-[#e5e2db] flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-[#666666]">
              Submitting archives visit, sends prescription to pharmacy queue, and records billing.
            </span>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveAppointment(null)}
                className="px-4 py-2 border border-[#e5e2db] bg-white text-xs uppercase tracking-wider font-semibold text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition cursor-pointer"
              >
                Close Station
              </button>
              <button
                onClick={handleCompleteConsultation}
                className="btn-editorial flex items-center gap-2"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Complete Consultation</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Schedule & Time Off */}
      {activeTab === 'leave' && (
        <div className="bg-white border border-[#e5e2db] shadow-xs p-6 sm:p-8 space-y-6">
          <div className="border-b border-[#e5e2db] pb-4">
            <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">
              Doctor Schedule &amp; Leave Management
            </h3>
            <p className="text-xs text-[#666666] mt-1">
              Mark scheduled leave or emergency time-off. Conflicting appointments are automatically cancelled and logged.
            </p>
          </div>

          <form onSubmit={handleMarkLeave} className="max-w-md space-y-5">
            <div className="field">
              <label>Select Leave Date *</label>
              <input
                type="date"
                required
                value={leaveDate}
                onChange={(e) => setLeaveDate(e.target.value)}
                className="input-hairline"
              />
            </div>
            <div className="field">
              <label>Reason for Leave *</label>
              <input
                type="text"
                required
                placeholder="e.g. Attending National Cardiology Summit"
                value={leaveReason}
                onChange={(e) => setLeaveReason(e.target.value)}
                className="input-hairline"
              />
            </div>
            <button
              type="submit"
              disabled={isSubmittingLeave}
              className="btn-editorial flex items-center gap-2"
            >
              <CalendarOff className="w-3.5 h-3.5" />
              <span>{isSubmittingLeave ? 'Registering...' : 'Mark Leave & Resolve Conflicts'}</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
