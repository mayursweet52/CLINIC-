import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Activity, 
  Stethoscope, 
  Users, 
  Pill, 
  Receipt, 
  ShieldAlert, 
  CalendarDays, 
  CheckCircle2, 
  Cloud, 
  Database, 
  UserCheck,
  ChevronDown,
  Contact2
} from 'lucide-react';
import { WorkspaceModal } from '../workspace/WorkspaceModal';

export type AppPageId = 'BOOKING' | 'RECEPTION' | 'DOCTOR' | 'PHARMACY' | 'BILLING' | 'PATIENTS' | 'ADMIN';

interface HeaderProps {
  activePage: AppPageId;
  setActivePage: (page: AppPageId) => void;
}

export function Header({ activePage, setActivePage }: HeaderProps) {
  const {
    activeDoctorId,
    setActiveDoctorId,
    doctors,
    isRealtimeConnected,
    workspaceToken,
    seedDefaultData,
    appointments,
    prescriptions,
    billings,
  } = useClinic();

  const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState(false);

  // Counters for live badges
  const waitingCount = appointments.filter((a) => a.status === 'ARRIVED').length;
  const pendingRxCount = prescriptions.filter((p) => p.status === 'PENDING').length;
  const pendingBillCount = billings.filter((b) => b.paymentStatus === 'PENDING').length;

  // The 7 Dedicated Separate Pages
  const pages: { id: AppPageId; label: string; icon: any; badge?: number }[] = [
    { id: 'BOOKING', label: 'Appointments', icon: CalendarDays },
    { id: 'RECEPTION', label: 'Queue', icon: Users, badge: waitingCount },
    { id: 'DOCTOR', label: 'Clinical', icon: Stethoscope },
    { id: 'PHARMACY', label: 'Pharmacy', icon: Pill, badge: pendingRxCount },
    { id: 'BILLING', label: 'Billing', icon: Receipt, badge: pendingBillCount },
    { id: 'PATIENTS', label: 'Patients', icon: Contact2 },
    { id: 'ADMIN', label: 'Admin', icon: ShieldAlert },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#f8f7f4] border-b border-[#e5e2db]">
        {/* Top brand line */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Brand Logo & Name */}
            <div 
              className="flex items-center gap-3 cursor-pointer" 
              onClick={() => setActivePage('BOOKING')}
              title="Return to Clinic Booking"
            >
              <div>
                <h1 className="font-cormorant text-2xl sm:text-3xl font-semibold tracking-[-0.02em] text-[#1a1a1a]">
                  ClinicOS — Apex
                </h1>
                <p className="text-[10px] uppercase tracking-[0.1em] text-[#666666] font-medium">
                  Smart OPD Management • Realtime System
                </p>
              </div>
            </div>

            {/* Right side status indicators & Workspace */}
            <div className="flex items-center gap-3 sm:gap-4">
              {/* Session Tag */}
              <div className="hidden lg:block text-[11px] font-semibold tracking-[0.08em] text-[#666666] uppercase">
                Demo Session — Oct 23
              </div>

              <span className="hidden lg:inline text-[#e5e2db]">|</span>

              {/* Real-time sync badge */}
              <div 
                className="flex items-center gap-2 text-xs text-[#666666]"
                title={isRealtimeConnected ? 'Firestore real-time event sync active' : 'Local sync cache'}
              >
                <span className="pulse" />
                <span className="hidden sm:inline text-[11px] uppercase tracking-[0.05em] font-medium text-[#4a6659]">
                  {isRealtimeConnected ? 'Firestore Active' : 'Connecting'}
                </span>
              </div>

              {/* Google Workspace Button */}
              <button
                onClick={() => setIsWorkspaceModalOpen(true)}
                className={`flex items-center gap-1.5 px-3 py-1.5 border text-xs font-semibold uppercase tracking-[0.06em] transition cursor-pointer ${
                  workspaceToken
                    ? 'bg-[#f2f5f4] border-[#4a6659] text-[#4a6659]'
                    : 'bg-white border-[#e5e2db] text-[#1a1a1a] hover:border-[#1a1a1a]'
                }`}
                title="Google Calendar, Sheets, Gmail & Contacts"
              >
                <Cloud className={`w-3.5 h-3.5 ${workspaceToken ? 'text-[#4a6659]' : 'text-[#666666]'}`} />
                <span className="hidden md:inline">Workspace</span>
                {workspaceToken ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4a6659]" />
                ) : (
                  <span className="text-[10px] text-[#4a6659]">Link</span>
                )}
              </button>

              {/* Active Doctor Selector (when viewing DOCTOR OPD page) */}
              {activePage === 'DOCTOR' && (
                <div className="relative">
                  <select
                    value={activeDoctorId}
                    onChange={(e) => setActiveDoctorId(e.target.value)}
                    className="text-xs font-medium bg-white border border-[#e5e2db] text-[#1a1a1a] px-2.5 py-1.5 pr-6 cursor-pointer focus:outline-hidden focus:border-[#4a6659] appearance-none"
                  >
                    {doctors.map((doc) => (
                      <option key={doc.id} value={doc.id}>
                        {doc.name} ({doc.roomNumber})
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-[#666666] absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              )}

              {/* Reset/Seed Data */}
              <button
                onClick={seedDefaultData}
                className="hidden xl:flex items-center gap-1 px-2.5 py-1.5 border border-[#e5e2db] bg-white text-xs font-medium text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition cursor-pointer"
                title="Reload initial demo clinic records"
              >
                <Database className="w-3.5 h-3.5 text-[#666666]" />
                <span className="text-[10px] uppercase tracking-[0.05em]">Seed</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dedicated Separate Pages Navigation Bar (Variation 3 Links) */}
        <div className="border-t border-[#e5e2db] px-4 sm:px-6 lg:px-8 bg-[#f8f7f4]">
          <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto no-scrollbar py-3">
            <div className="flex items-center gap-6 sm:gap-10">
              {pages.map((item) => {
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActivePage(item.id)}
                    className={`text-[11px] font-semibold uppercase tracking-[0.1em] transition cursor-pointer relative pb-1 whitespace-nowrap ${
                      isActive
                        ? 'text-[#1a1a1a] after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1 font-bold'
                        : 'text-[#666666] hover:text-[#1a1a1a]'
                    }`}
                  >
                    <span>{item.label}</span>
                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="ml-1 text-[10px] text-[#4a6659] font-bold">
                        ({item.badge})
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            
            <div className="hidden md:flex items-center gap-2 text-[10px] uppercase tracking-[0.08em] text-[#666666]">
              <span>Chamber Active</span>
              <span className="w-1 h-1 rounded-full bg-[#4a6659]" />
              <span className="font-semibold text-[#1a1a1a]">Dr. Ananya Sharma</span>
            </div>
          </div>
        </div>
      </header>

      {/* Google Workspace Integration Modal */}
      <WorkspaceModal
        isOpen={isWorkspaceModalOpen}
        onClose={() => setIsWorkspaceModalOpen(false)}
      />
    </>
  );
}
