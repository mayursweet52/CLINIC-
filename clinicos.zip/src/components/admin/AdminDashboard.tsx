import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  ShieldAlert, 
  Activity, 
  Users, 
  Pill, 
  Receipt, 
  Clock, 
  FileSpreadsheet, 
  CheckCircle2, 
  Lock, 
  Database,
  Building,
  UserCheck
} from 'lucide-react';

export function AdminDashboard() {
  const {
    doctors,
    appointments,
    patients,
    billings,
    inventory,
    auditLogs,
    exportBillingToSheet,
    exportAppointmentsToSheet,
    seedDefaultData,
    isRealtimeConnected,
    showToast,
  } = useClinic();

  const [activeTab, setActiveTab] = useState<'overview' | 'audit' | 'doctors'>('overview');
  const [isExporting, setIsExporting] = useState(false);

  // Computed metrics
  const totalRevenue = billings
    .filter((b) => b.paymentStatus === 'PAID')
    .reduce((sum, b) => sum + b.totalAmount, 0);

  const totalPatients = patients.length;
  const totalAppointments = appointments.length;
  const lowStockCount = inventory.filter((i) => i.quantity <= i.reorderLevel).length;

  const handleExportAll = async () => {
    try {
      setIsExporting(true);
      const url = await exportBillingToSheet();
      if (url) {
        window.open(url, '_blank');
      }
    } catch (err: any) {
      showToast('Error', err?.message, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="border-b border-[#e5e2db] pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
            Governance &amp; Audit Operations
          </h2>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            Clinical KPIs, immutable audit logs &bull; Doctor credentials
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportAll}
            disabled={isExporting}
            className="btn-editorial flex items-center gap-2 disabled:opacity-50"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Exporting...' : 'Export Master Ledger'}</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-8 border-b border-[#e5e2db]">
        <button
          onClick={() => setActiveTab('overview')}
          className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
            activeTab === 'overview'
              ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
              : 'text-[#666666] hover:text-[#1a1a1a]'
          }`}
        >
          Executive Overview
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
            activeTab === 'audit'
              ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
              : 'text-[#666666] hover:text-[#1a1a1a]'
          }`}
        >
          Real-time Audit Logs ({auditLogs.length})
        </button>
        <button
          onClick={() => setActiveTab('doctors')}
          className={`pb-3 text-xs uppercase tracking-[0.1em] font-semibold transition cursor-pointer relative ${
            activeTab === 'doctors'
              ? 'text-[#1a1a1a] font-bold after:content-[""] after:block after:w-full after:h-[1px] after:bg-[#1a1a1a] after:mt-1'
              : 'text-[#666666] hover:text-[#1a1a1a]'
          }`}
        >
          Doctors &amp; Specialists ({doctors.length})
        </button>
      </div>

      {/* TAB 1: Executive Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* KPI Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="stat-block">
              <span className="stat-label">Settled Collections</span>
              <div className="stat-val mt-1">
                ₹{totalRevenue.toLocaleString('en-IN')}
              </div>
              <span className="text-[11px] text-[#4a6659] mt-1 block font-medium">
                Live billing transactions
              </span>
            </div>

            <div className="stat-block">
              <span className="stat-label">Total Patients</span>
              <div className="stat-val mt-1">
                {totalPatients}
              </div>
              <span className="text-[11px] text-[#666666] mt-1 block">
                Enrolled in clinic registry
              </span>
            </div>

            <div className="stat-block">
              <span className="stat-label">OPD Consultations</span>
              <div className="stat-val mt-1">
                {totalAppointments}
              </div>
              <span className="text-[11px] text-[#666666] mt-1 block">
                Across {doctors.length} specialties
              </span>
            </div>

            <div className="stat-block">
              <span className="stat-label">Pharmacy Stock Alerts</span>
              <div className={`stat-val mt-1 ${lowStockCount > 0 ? 'text-[#a83232]' : 'text-[#1a1a1a]'}`}>
                {lowStockCount}
              </div>
              <span className="text-[11px] text-[#666666] mt-1 block">
                Formulations below safety level
              </span>
            </div>
          </div>

          {/* Clinic Information Card */}
          <div className="bg-white border border-[#e5e2db] p-8 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e5e2db] pb-4">
              <div>
                <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Apex Metro Clinic Architecture</h3>
                <p className="text-xs text-[#666666] mt-0.5">Enterprise Cloud Healthcare Facility Details</p>
              </div>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 border border-[#e5e2db] text-[#4a6659] bg-[#f8f7f4] self-start sm:self-auto">
                Tenant: org-apex-01 (PRO Tier)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
              <div className="p-4 border border-[#e5e2db] bg-[#f8f7f4]">
                <span className="stat-label block mb-1">Facility Type</span>
                <span className="font-semibold text-sm text-[#1a1a1a] block">Multi-Specialty OPD Clinic</span>
                <span className="text-[11px] text-[#666666] mt-1 block">General Medicine, Cardiology, Pediatrics, Dermatology</span>
              </div>
              <div className="p-4 border border-[#e5e2db] bg-[#f8f7f4]">
                <span className="stat-label block mb-1">Database Architecture</span>
                <span className="font-semibold text-sm text-[#4a6659] flex items-center gap-1.5 mt-0.5">
                  <span className="w-2 h-2 rounded-full bg-[#4a6659] animate-pulse" />
                  Cloud Firestore &lt;1s Real-time
                </span>
                <span className="text-[11px] text-[#666666] mt-1 block">Optimistic updates &amp; bidirectional sync</span>
              </div>
              <div className="p-4 border border-[#e5e2db] bg-[#f8f7f4]">
                <span className="stat-label block mb-1">Workspace Suite</span>
                <span className="font-semibold text-sm text-[#1a1a1a] block">Google Cloud Ecosystem</span>
                <span className="text-[11px] text-[#666666] mt-1 block">Calendar &bull; Sheets &bull; Gmail &bull; Contacts</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Real-time Audit Logs */}
      {activeTab === 'audit' && (
        <div className="bg-white border border-[#e5e2db] shadow-xs overflow-hidden">
          <div className="p-4 border-b border-[#e5e2db] bg-[#f8f7f4] flex items-center justify-between">
            <div>
              <h3 className="text-xs uppercase tracking-wider font-semibold text-[#1a1a1a]">System Activity &amp; Audit Trail</h3>
              <p className="text-xs text-[#666666] mt-0.5">
                Every clinical and billing mutation is immutably logged with timestamp, user role, and resource ID.
              </p>
            </div>
            <span className="text-xs font-mono text-[#666666]">
              {auditLogs.length} events logged
            </span>
          </div>

          <div className="overflow-x-auto p-4 pt-2">
            <table className="queue-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Staff User</th>
                  <th>Role</th>
                  <th>Action</th>
                  <th>Resource</th>
                  <th>Event Details</th>
                </tr>
              </thead>
              <tbody className="font-mono text-xs">
                {auditLogs.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-[#666666] font-sans italic">
                      No security audit events recorded yet. Perform clinical actions to populate live logs.
                    </td>
                  </tr>
                ) : (
                  auditLogs.map((log) => (
                    <tr key={log.id}>
                      <td className="text-xs text-[#666666]">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </td>
                      <td className="font-semibold text-[#1a1a1a] font-sans">
                        {log.userName}
                      </td>
                      <td>
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-[#666666]">
                          {log.role}
                        </span>
                      </td>
                      <td className="text-[#4a6659] font-bold">
                        {log.action}
                      </td>
                      <td className="text-[#666666]">
                        {log.resource}
                      </td>
                      <td className="text-[#1a1a1a] max-w-xs truncate font-sans text-xs">
                        {log.details}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Doctors Directory */}
      {activeTab === 'doctors' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {doctors.map((doc) => (
            <div key={doc.id} className="bg-white border border-[#e5e2db] p-6 shadow-xs space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">{doc.name}</h4>
                  <p className="text-xs text-[#4a6659] font-medium">{doc.specialty}</p>
                  <p className="text-[11px] text-[#666666]">{doc.qualification}</p>
                </div>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-[#e5e2db] bg-[#f8f7f4] text-[#1a1a1a]">
                  {doc.roomNumber}
                </span>
              </div>

              <div className="border-t border-[#e5e2db] pt-4 grid grid-cols-2 gap-3 text-xs text-[#666666]">
                <div>
                  <span className="stat-label block">Consultation Fee</span>
                  <span className="font-semibold text-[#1a1a1a] mt-0.5 block">₹{doc.consultationFee}</span>
                </div>
                <div>
                  <span className="stat-label block">Experience</span>
                  <span className="font-semibold text-[#1a1a1a] mt-0.5 block">{doc.experienceYears} Years</span>
                </div>
                <div>
                  <span className="stat-label block">Email</span>
                  <span className="text-[#1a1a1a] mt-0.5 block truncate">{doc.email}</span>
                </div>
                <div>
                  <span className="stat-label block">Phone</span>
                  <span className="text-[#1a1a1a] mt-0.5 block">{doc.phone}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
