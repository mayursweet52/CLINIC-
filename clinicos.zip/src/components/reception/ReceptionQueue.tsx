import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Users, 
  Search, 
  UserPlus, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  Contact, 
  Activity, 
  X,
  RefreshCw
} from 'lucide-react';

export function ReceptionQueue() {
  const {
    appointments,
    patients,
    doctors,
    checkInPatient,
    bookAppointment,
    syncPatientToGoogleContacts,
    syncToCalendar,
    sendAppointmentConfirmationEmail,
    workspaceToken,
    showToast,
  } = useClinic();

  const [searchQuery, setSearchQuery] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('ALL');
  const [dateFilter, setDateFilter] = useState<'TODAY' | 'ALL'>('ALL');
  const [isNewBookingModalOpen, setIsNewBookingModalOpen] = useState(false);

  // New Walk-in form state
  const [patName, setPatName] = useState('');
  const [patPhone, setPatPhone] = useState('');
  const [patEmail, setPatEmail] = useState('');
  const [patAge, setPatAge] = useState(30);
  const [patGender, setPatGender] = useState('MALE');
  const [selectedDoctorId, setSelectedDoctorId] = useState(doctors[0]?.id || '');
  const [apptReason, setApptReason] = useState('Walk-in OPD consultation');
  const [syncCal, setSyncCal] = useState(true);
  const [sendMail, setSendMail] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const dateScopedAppointments = dateFilter === 'TODAY' 
    ? appointments.filter((a) => a.appointmentDate === today)
    : appointments;

  // Filtered appointments
  const filteredAppointments = dateScopedAppointments.filter((a) => {
    const matchesSearch =
      a.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.patientPhone.includes(searchQuery) ||
      a.tokenNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = filterDepartment === 'ALL' || a.department === filterDepartment;
    return matchesSearch && matchesDept;
  });

  // Token board counts
  const arrivedList = appointments.filter((a) => a.status === 'ARRIVED');
  const inConsultList = appointments.filter((a) => a.status === 'IN_CONSULTATION');
  const scheduledList = appointments.filter((a) => a.status === 'SCHEDULED');
  const completedList = appointments.filter((a) => a.status === 'COMPLETED');

  // Submit Walk-in appointment
  const handleCreateWalkIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patName || !patPhone) {
      showToast('Validation', 'Please provide patient name and phone number.', 'warning');
      return;
    }

    try {
      setIsSubmitting(true);
      const currentTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const res = await bookAppointment({
        patientName: patName,
        patientPhone: patPhone,
        patientEmail: patEmail || undefined,
        patientAge: Number(patAge),
        patientGender: patGender as any,
        doctorId: selectedDoctorId || doctors[0]?.id,
        appointmentDate: today,
        appointmentTime: currentTimeStr,
        reason: apptReason,
        syncCalendar: syncCal,
        sendEmail: sendMail,
      });

      // Automatically check in the walk-in
      await checkInPatient(res.appointment.id);

      setIsNewBookingModalOpen(false);
      setPatName('');
      setPatPhone('');
      setPatEmail('');
      setApptReason('Walk-in OPD consultation');
      showToast('Walk-in Registered', `Token #${res.token} issued to ${res.appointment.patientName}`, 'success');
    } catch (err: any) {
      showToast('Booking Error', err?.message || 'Failed to book appointment', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Reception Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#e5e2db] pb-6">
        <div>
          <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
            Reception Desk &amp; Patient Queue
          </h2>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            Live Token Routing &bull; Waiting Lounge &bull; OPD Walk-ins
          </p>
        </div>

        <button
          onClick={() => setIsNewBookingModalOpen(true)}
          className="btn-editorial flex items-center gap-2 self-start sm:self-center"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>New Walk-in / Intake</span>
        </button>
      </div>

      {/* Live OPD Token Stat Blocks */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Waiting In Lobby */}
        <div className="stat-block">
          <div className="flex items-center justify-between mb-1">
            <span className="stat-label">In Waiting Area</span>
            <span className="pulse" />
          </div>
          <div className="stat-val">{arrivedList.length}</div>
          <p className="text-[11px] text-[#666666] mt-1">Est. wait: ~{Math.min(arrivedList.length * 10, 45)} mins</p>
        </div>

        {/* In Consultation Room */}
        <div className="stat-block">
          <div className="flex items-center justify-between mb-1">
            <span className="stat-label">In Consultation</span>
            <Activity className="w-3.5 h-3.5 text-[#4a6659]" />
          </div>
          <div className="stat-val">{inConsultList.length}</div>
          <p className="text-[11px] text-[#666666] mt-1">Active doctor chambers</p>
        </div>

        {/* Scheduled Today */}
        <div className="stat-block">
          <div className="flex items-center justify-between mb-1">
            <span className="stat-label">Upcoming / Booked</span>
            <Clock className="w-3.5 h-3.5 text-[#666666]" />
          </div>
          <div className="stat-val">{scheduledList.length}</div>
          <p className="text-[11px] text-[#666666] mt-1">Awaiting lobby check-in</p>
        </div>

        {/* Completed */}
        <div className="stat-block">
          <div className="flex items-center justify-between mb-1">
            <span className="stat-label">Completed Today</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-[#4a6659]" />
          </div>
          <div className="stat-val">{completedList.length}</div>
          <p className="text-[11px] text-[#666666] mt-1">Prescription &amp; billing done</p>
        </div>
      </div>

      {/* Queue Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-4 py-2 border-b border-[#e5e2db]">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#666666] absolute left-0 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search queue by Patient Name, Phone, or Token..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-xs pl-6 pr-4 py-2 bg-transparent border-none border-b border-[#e5e2db] focus:outline-hidden focus:border-[#4a6659] text-[#1a1a1a]"
          />
        </div>

        <select
          value={filterDepartment}
          onChange={(e) => setFilterDepartment(e.target.value)}
          className="text-xs py-1.5 px-2 border-b border-[#e5e2db] bg-transparent text-[#1a1a1a] focus:outline-hidden focus:border-[#4a6659] w-full sm:w-auto font-medium cursor-pointer"
        >
          <option value="ALL">All Departments</option>
          <option value="Cardiology">Cardiology</option>
          <option value="General Medicine">General Medicine</option>
          <option value="Pediatrics">Pediatrics</option>
          <option value="Orthopedics">Orthopedics</option>
        </select>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <button
            type="button"
            onClick={() => setDateFilter('ALL')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.06em] transition cursor-pointer ${
              dateFilter === 'ALL'
                ? 'bg-[#1a1a1a] text-white'
                : 'border border-[#e5e2db] bg-white text-[#666666] hover:text-[#1a1a1a]'
            }`}
          >
            All Dates ({appointments.length})
          </button>
          <button
            type="button"
            onClick={() => setDateFilter('TODAY')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.06em] transition cursor-pointer ${
              dateFilter === 'TODAY'
                ? 'bg-[#1a1a1a] text-white'
                : 'border border-[#e5e2db] bg-white text-[#666666] hover:text-[#1a1a1a]'
            }`}
          >
            Today's Visits
          </button>
        </div>
      </div>

      {/* Live Table */}
      <div className="bg-white border border-[#e5e2db] p-6 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="queue-table">
            <thead>
              <tr>
                <th>Token #</th>
                <th>Patient Information</th>
                <th>Doctor &amp; Room</th>
                <th>Slot Time</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-xs text-[#666666] italic">
                    No matching appointments found in the OPD queue.
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((appt) => {
                  const pat = patients.find((p) => p.id === appt.patientId);

                  return (
                    <tr key={appt.id}>
                      {/* Token */}
                      <td>
                        <div className="token-circle">{appt.tokenNumber}</div>
                      </td>

                      {/* Patient info */}
                      <td>
                        <strong className="font-semibold text-[#1a1a1a]">{appt.patientName}</strong>
                        <div className="text-xs text-[#666666] flex items-center gap-2 mt-0.5">
                          <span>{appt.patientPhone}</span>
                          {pat?.bloodGroup && <span>&bull; {pat.bloodGroup}</span>}
                          {pat?.allergies && pat.allergies.length > 0 && (
                            <span className="text-[#a83232] font-semibold">&bull; Allergies!</span>
                          )}
                        </div>
                      </td>

                      {/* Doctor */}
                      <td>
                        <span className="font-medium text-[#1a1a1a]">{appt.doctorName}</span>
                        <div className="text-xs text-[#4a6659]">{appt.department}</div>
                      </td>

                      {/* Time */}
                      <td className="text-xs font-medium text-[#1a1a1a]">
                        {appt.appointmentTime}
                      </td>

                      {/* Status */}
                      <td>
                        <span className="text-[10px] uppercase tracking-wider font-semibold text-[#4a6659]">
                          {appt.status.replace('_', ' ')}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="text-right space-x-2 whitespace-nowrap">
                        {appt.status === 'SCHEDULED' && (
                          <button
                            onClick={() => checkInPatient(appt.id)}
                            className="px-2.5 py-1 bg-[#1a1a1a] text-white text-[10px] uppercase tracking-wider font-semibold hover:opacity-90 transition cursor-pointer"
                          >
                            Check In
                          </button>
                        )}

                        {/* Google Contacts sync icon */}
                        {pat && (
                          <button
                            onClick={() => syncPatientToGoogleContacts(pat.id)}
                            className="p-1 border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition inline-flex items-center cursor-pointer"
                            title="Sync patient into Google Contacts"
                          >
                            <Contact className="w-3.5 h-3.5 text-[#4a6659]" />
                          </button>
                        )}

                        {/* Calendar sync */}
                        <button
                          onClick={() => syncToCalendar(appt.id)}
                          className="p-1 border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] transition inline-flex items-center cursor-pointer"
                          title="Add to Google Calendar"
                        >
                          <Calendar className="w-3.5 h-3.5 text-[#4a6659]" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* WALK-IN / NEW BOOKING MODAL */}
      {isNewBookingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-2xs p-4 overflow-y-auto">
          <div className="bg-white max-w-lg w-full border border-[#e5e2db] p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#e5e2db] pb-4">
              <div>
                <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Register Walk-in Patient</h3>
                <p className="text-[10px] uppercase tracking-wider text-[#666666]">Instant token allocation &amp; check-in</p>
              </div>
              <button
                onClick={() => setIsNewBookingModalOpen(false)}
                className="text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateWalkIn} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="field">
                  <label>Patient Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Full name"
                    value={patName}
                    onChange={(e) => setPatName(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 98..."
                    value={patPhone}
                    onChange={(e) => setPatPhone(e.target.value)}
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="field">
                  <label>Age</label>
                  <input
                    type="number"
                    value={patAge}
                    onChange={(e) => setPatAge(Number(e.target.value))}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Gender</label>
                  <select
                    value={patGender}
                    onChange={(e) => setPatGender(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
                <div className="field">
                  <label>Email</label>
                  <input
                    type="email"
                    placeholder="Optional"
                    value={patEmail}
                    onChange={(e) => setPatEmail(e.target.value)}
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="field">
                <label>Assign Doctor *</label>
                <select
                  value={selectedDoctorId}
                  onChange={(e) => setSelectedDoctorId(e.target.value)}
                  className="input-hairline cursor-pointer"
                >
                  {doctors.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name} — {d.specialty} ({d.roomNumber}, ₹{d.consultationFee})
                    </option>
                  ))}
                </select>
              </div>

              <div className="field">
                <label>Reason for Visit</label>
                <input
                  type="text"
                  value={apptReason}
                  onChange={(e) => setApptReason(e.target.value)}
                  className="input-hairline"
                />
              </div>

              {/* Workspace checkboxes */}
              <div className="p-3 bg-[#f8f7f4] border border-[#e5e2db] space-y-2 text-xs text-[#666666]">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={syncCal}
                    onChange={(e) => setSyncCal(e.target.checked)}
                    className="accent-[#4a6659]"
                  />
                  <span>Sync visit to clinic Google Calendar</span>
                </label>
                {patEmail && (
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={sendMail}
                      onChange={(e) => setSendMail(e.target.checked)}
                      className="accent-[#4a6659]"
                    />
                    <span>Email token confirmation via Gmail</span>
                  </label>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewBookingModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold uppercase tracking-[0.06em] text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn-editorial flex items-center gap-2"
                >
                  {isSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                  <span>Allocate Token &amp; Check In</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
