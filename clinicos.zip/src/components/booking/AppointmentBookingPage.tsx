import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import confetti from 'canvas-confetti';
import { 
  Calendar, 
  Mail, 
  Search, 
  Check, 
  ArrowRight,
  RefreshCw,
  ExternalLink,
  Users
} from 'lucide-react';
import { HealthAppointment } from '../../types/clinic';
import { AppPageId } from '../layout/Header';

interface AppointmentBookingPageProps {
  onNavigateToPage?: (page: AppPageId) => void;
}

export function AppointmentBookingPage({ onNavigateToPage }: AppointmentBookingPageProps) {
  const {
    doctors,
    appointments,
    bookAppointment,
    checkInPatient,
    syncToCalendar,
    sendAppointmentConfirmationEmail,
    workspaceToken,
    showToast,
  } = useClinic();

  // Form Fields
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientAge, setPatientAge] = useState<number>(32);
  const [patientGender, setPatientGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [selectedDept, setSelectedDept] = useState<string>('Cardiology');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(doctors[0]?.id || 'doc-001');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedTime, setSelectedTime] = useState<string>('10:30 AM');
  const [reason, setReason] = useState('Routine OPD Consultation');
  const [syncCalendar, setSyncCalendar] = useState(true);
  const [sendEmail, setSendEmail] = useState(true);

  // Status & Confirmation
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastBookedAppt, setLastBookedAppt] = useState<HealthAppointment | null>(null);
  const [lastBookedToken, setLastBookedToken] = useState<string | null>(null);
  const [queueSearch, setQueueSearch] = useState('');

  const departments = [
    'Cardiology',
    'General Medicine',
    'Pediatrics',
    'Orthopedics',
  ];

  const timeSlots = [
    '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM',
    '11:30 AM', '12:00 PM', '04:00 PM', '04:30 PM',
    '05:00 PM', '05:30 PM', '06:00 PM', '06:30 PM',
  ];

  const deptDoctors = doctors.filter((d) => d.department === selectedDept);

  const handleDepartmentChange = (deptName: string) => {
    setSelectedDept(deptName);
    const docInDept = doctors.find((d) => d.department === deptName);
    if (docInDept) {
      setSelectedDoctorId(docInDept.id);
    }
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!patientName.trim()) {
      showToast('Name Required', 'Please enter the patient full name.', 'warning');
      return;
    }
    if (!patientPhone.trim()) {
      showToast('Phone Required', 'Please enter a valid contact phone number.', 'warning');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await bookAppointment({
        patientName: patientName.trim(),
        patientPhone: patientPhone.trim(),
        patientEmail: patientEmail.trim() || undefined,
        patientAge: Number(patientAge) || 30,
        patientGender,
        doctorId: selectedDoctorId || doctors[0]?.id || 'doc-001',
        appointmentDate: selectedDate || new Date().toISOString().split('T')[0],
        appointmentTime: selectedTime || '10:30 AM',
        reason: reason || 'OPD Consultation',
        syncCalendar,
        sendEmail,
      });

      setLastBookedAppt(res.appointment);
      setLastBookedToken(res.token);

      try {
        confetti({
          particleCount: 60,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // Confetti fallback
      }

      showToast('Token Generated', `OPD Token #${res.token} created for ${res.appointment.patientName}`, 'success');
    } catch (err: any) {
      showToast('Booking Error', err?.message || 'Could not complete appointment booking.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const waitingCount = appointments.filter((a) => a.status === 'ARRIVED').length;
  const filteredAppointments = appointments.filter((a) => {
    const q = queueSearch.toLowerCase();
    return (
      a.patientName.toLowerCase().includes(q) ||
      a.tokenNumber.toLowerCase().includes(q) ||
      a.doctorName.toLowerCase().includes(q) ||
      a.department.toLowerCase().includes(q)
    );
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
      {/* Left Column: Hero Text, Stat Blocks, Live Queue Table */}
      <div className="lg:col-span-6 xl:col-span-7 space-y-12">
        {/* Hero Title and Subtitle */}
        <div className="space-y-4">
          <h1 className="font-cormorant text-5xl sm:text-6xl lg:text-7xl font-medium tracking-tight text-[#1a1a1a] leading-[0.9]">
            Opd Booking &amp;<br />Clinical Intake
          </h1>
          <p className="text-base sm:text-lg leading-relaxed text-[#666666] max-w-xl font-normal">
            Unified platform for multi-tenant clinic management. Streamlining patient flow from registration to discharge with AI clinical intelligence.
          </p>
        </div>

        {/* Stat Blocks */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <div className="stat-block">
            <div className="stat-val">{appointments.length}</div>
            <div className="stat-label">Total Appointments</div>
          </div>
          <div className="stat-block">
            <div className="stat-val">{waitingCount}</div>
            <div className="stat-label">In Live Queue</div>
          </div>
          <div className="stat-block col-span-2 sm:col-span-1">
            <div className="stat-val">{doctors.length}</div>
            <div className="stat-label">Consultants on Duty</div>
          </div>
        </div>

        {/* Live Appointments Table */}
        <div className="space-y-4 pt-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#e5e2db] pb-3">
            <h2 className="font-cormorant text-2xl font-medium italic text-[#1a1a1a]">
              Live Appointments ({appointments.length})
            </h2>

            <div className="flex items-center gap-3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Filter queue..."
                  value={queueSearch}
                  onChange={(e) => setQueueSearch(e.target.value)}
                  className="text-xs bg-transparent border-b border-[#e5e2db] py-1 px-1 pr-6 focus:outline-hidden focus:border-[#4a6659] text-[#1a1a1a]"
                />
                <Search className="w-3.5 h-3.5 text-[#666666] absolute right-1 top-1.5 pointer-events-none" />
              </div>

              {onNavigateToPage && (
                <button
                  onClick={() => onNavigateToPage('RECEPTION')}
                  className="text-xs uppercase tracking-[0.08em] font-semibold text-[#4a6659] hover:text-[#1a1a1a] transition cursor-pointer"
                >
                  Full Queue &rarr;
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="queue-table">
              <thead>
                <tr>
                  <th>Token</th>
                  <th>Patient Info</th>
                  <th>Consultant</th>
                  <th>Timing</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAppointments.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-xs text-[#666666] italic">
                      No appointments matching query.
                    </td>
                  </tr>
                ) : (
                  filteredAppointments.slice(0, 6).map((appt) => (
                    <tr key={appt.id}>
                      <td>
                        <div className="token-circle">{appt.tokenNumber}</div>
                      </td>
                      <td>
                        <strong className="font-semibold text-[#1a1a1a]">{appt.patientName}</strong>
                        <br />
                        <small className="text-xs text-[#666666]">{appt.patientPhone}</small>
                      </td>
                      <td>
                        <span className="text-[#1a1a1a]">{appt.doctorName}</span>
                        <br />
                        <small className="text-xs text-[#666666]">{appt.department}</small>
                      </td>
                      <td className="text-xs font-medium text-[#1a1a1a]">
                        {appt.appointmentTime}
                      </td>
                      <td>
                        <span className="text-[10px] uppercase tracking-wider font-semibold text-[#4a6659]">
                          {appt.status}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-1.5">
                          {appt.status === 'SCHEDULED' && (
                            <button
                              onClick={() => checkInPatient(appt.id)}
                              className="text-[11px] font-semibold text-[#4a6659] hover:underline"
                              title="Check in patient to queue"
                            >
                              Check-In
                            </button>
                          )}
                          <button
                            onClick={() => syncToCalendar(appt.id)}
                            className="p-1 rounded text-[#666666] hover:text-[#1a1a1a]"
                            title="Add to Google Calendar"
                          >
                            <Calendar className="w-3.5 h-3.5 text-[#4a6659]" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Right Column: The Booking Shell */}
      <div className="lg:col-span-6 xl:col-span-5">
        <div className="bg-white p-6 sm:p-10 border border-[#e5e2db] space-y-8 shadow-xs">
          {/* Recent Token Confirmation Block */}
          {lastBookedAppt && lastBookedToken && (
            <div className="stat-block space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="stat-label">Token Generated</span>
                  <div className="font-cormorant text-3xl font-semibold text-[#1a1a1a] mt-0.5">
                    Token #{lastBookedToken}
                  </div>
                </div>
                <div className="token-circle text-base">{lastBookedToken}</div>
              </div>

              <div className="text-xs text-[#666666] border-t border-[#e5e2db] pt-2 space-y-1">
                <p><strong>Patient:</strong> {lastBookedAppt.patientName} ({lastBookedAppt.patientPhone})</p>
                <p><strong>Consultant:</strong> {lastBookedAppt.doctorName} &bull; {lastBookedAppt.appointmentTime}</p>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => checkInPatient(lastBookedAppt.id)}
                  className="btn-editorial text-[10px] py-2 px-3 flex items-center gap-1"
                >
                  <Check className="w-3.5 h-3.5" /> Check In Now
                </button>
                <button
                  type="button"
                  onClick={() => syncToCalendar(lastBookedAppt.id)}
                  className="text-xs font-semibold px-3 py-2 border border-[#e5e2db] text-[#1a1a1a] hover:bg-white transition flex items-center gap-1"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#4a6659]" /> Calendar
                </button>
                {onNavigateToPage && (
                  <button
                    type="button"
                    onClick={() => onNavigateToPage('RECEPTION')}
                    className="text-xs font-semibold px-3 py-2 border border-[#e5e2db] text-[#1a1a1a] hover:bg-white transition ml-auto flex items-center gap-1"
                  >
                    <Users className="w-3.5 h-3.5 text-[#666666]" /> View Queue
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Direct Booking Form */}
          <form onSubmit={handleBookingSubmit} className="space-y-8">
            {/* Section 1: Patient Record */}
            <section>
              <h2 className="form-section-label">Patient Record</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-5">
                <div className="field">
                  <label>Full Name</label>
                  <input
                    type="text"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="Ramesh Kumar"
                    required
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Contact Phone</label>
                  <input
                    type="tel"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    required
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6 mb-5">
                <div className="field">
                  <label>Age</label>
                  <input
                    type="number"
                    value={patientAge}
                    onChange={(e) => setPatientAge(Number(e.target.value))}
                    min={1}
                    max={120}
                    required
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Gender</label>
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value as any)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
                <div className="field">
                  <label>Email Address</label>
                  <input
                    type="email"
                    value={patientEmail}
                    onChange={(e) => setPatientEmail(e.target.value)}
                    placeholder="name@domain.com"
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="field">
                <label>Chief Complaint / Reason for Visit</label>
                <input
                  type="text"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Routine OPD Consultation"
                  className="input-hairline"
                />
              </div>
            </section>

            {/* Section 2: Consultation Details */}
            <section>
              <h2 className="form-section-label">Consultation Details</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-5">
                <div className="field">
                  <label>Department</label>
                  <select
                    value={selectedDept}
                    onChange={(e) => handleDepartmentChange(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    {departments.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="field">
                  <label>Consultant</label>
                  <select
                    value={selectedDoctorId}
                    onChange={(e) => setSelectedDoctorId(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    {deptDoctors.map((doc) => (
                      <option key={doc.id} value={doc.id}>
                        {doc.name} ({doc.roomNumber})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                <div className="field">
                  <label>Consult Date</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="input-hairline cursor-pointer"
                  />
                </div>

                <div className="field">
                  <label>Requested Slot</label>
                  <select
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Cloud Sync Preferences */}
              <div className="flex flex-wrap items-center gap-6 py-3 border-t border-[#e5e2db] text-xs text-[#666666]">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={syncCalendar}
                    onChange={(e) => setSyncCalendar(e.target.checked)}
                    className="accent-[#4a6659]"
                  />
                  <span>Sync to Google Calendar</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={sendEmail}
                    onChange={(e) => setSendEmail(e.target.checked)}
                    className="accent-[#4a6659]"
                  />
                  <span>Dispatch Gmail Confirmation</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-editorial w-full sm:w-auto mt-4 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                <span>Confirm Appointment &amp; Generate Token</span>
              </button>
            </section>
          </form>
        </div>
      </div>
    </div>
  );
}
