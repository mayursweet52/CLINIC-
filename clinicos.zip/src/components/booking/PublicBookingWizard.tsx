import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import confetti from 'canvas-confetti';
import { 
  CalendarDays, 
  User, 
  Clock, 
  CheckCircle2, 
  Calendar, 
  Mail, 
  Stethoscope, 
  ChevronRight, 
  ArrowLeft,
  Sparkles,
  Phone,
  ShieldCheck,
  Building
} from 'lucide-react';
import { DoctorProfile } from '../../types/clinic';

export function PublicBookingWizard() {
  const {
    doctors,
    bookAppointment,
    syncToCalendar,
    sendAppointmentConfirmationEmail,
    workspaceToken,
    showToast,
  } = useClinic();

  const [step, setStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Wizard selections
  const [selectedDept, setSelectedDept] = useState<string>('Cardiology');
  const [selectedDoctor, setSelectedDoctor] = useState<DoctorProfile | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [selectedTime, setSelectedTime] = useState<string>('10:30 AM');

  // Patient details
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientAge, setPatientAge] = useState<number>(30);
  const [patientGender, setPatientGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [reason, setReason] = useState('');

  // Booking Result
  const [bookedResult, setBookedResult] = useState<{ token: string; apptId: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const departments = [
    { name: 'Cardiology', desc: 'Heart care, ECG, hypertension & lipid consults', icon: '❤️' },
    { name: 'General Medicine', desc: 'Fever, diabetes, infectious illnesses & wellness', icon: '🩺' },
    { name: 'Pediatrics', desc: 'Child health, immunization & newborn care', icon: '👶' },
    { name: 'Orthopedics', desc: 'Joint pain, fractures, spine & sports injuries', icon: '🦴' },
  ];

  const timeSlots = [
    '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM',
    '11:30 AM', '12:00 PM', '04:00 PM', '04:30 PM',
    '05:00 PM', '05:30 PM', '06:00 PM', '06:30 PM',
  ];

  // Available dates for next 7 days
  const availableDates = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return {
      iso: d.toISOString().split('T')[0],
      dayName: d.toLocaleDateString('en-US', { weekday: 'short' }),
      dateNumber: d.getDate(),
      month: d.toLocaleDateString('en-US', { month: 'short' }),
    };
  });

  const deptDoctors = doctors.filter((d) => d.department === selectedDept);

  // Submit Booking
  const handleConfirmBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoctor || !patientName || !patientPhone) return;

    try {
      setIsSubmitting(true);
      const res = await bookAppointment({
        patientName,
        patientPhone,
        patientEmail: patientEmail || undefined,
        patientAge: Number(patientAge),
        patientGender,
        doctorId: selectedDoctor.id,
        appointmentDate: selectedDate,
        appointmentTime: selectedTime,
        reason: reason || 'OPD Consultation',
        syncCalendar: true,
        sendEmail: true,
      });

      setBookedResult({
        token: res.token,
        apptId: res.appointment.id,
      });

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      setStep(5); // Success step
    } catch (err: any) {
      showToast('Booking Error', err?.message || 'Failed to confirm booking', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Wizard Header Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl text-center">
        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-white/10 text-teal-200 border border-white/20 inline-block mb-3">
          Patient Self-Booking Portal
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Book Your Clinic Consultation
        </h2>
        <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-lg mx-auto">
          Instant OPD queue token generation, Google Calendar reminder sync, and automated email confirmation.
        </p>

        {/* Step Indicator */}
        {step < 5 && (
          <div className="flex items-center justify-center gap-2 mt-6">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`flex items-center gap-2 ${s <= step ? 'text-teal-300 font-bold' : 'text-white/40'}`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border ${
                    s < step
                      ? 'bg-teal-500 text-white border-teal-400'
                      : s === step
                      ? 'bg-white text-slate-900 border-white'
                      : 'border-white/30 text-white/50'
                  }`}
                >
                  {s < step ? '✓' : s}
                </div>
                <span className="text-xs hidden sm:inline">
                  {s === 1 ? 'Specialty' : s === 2 ? 'Doctor' : s === 3 ? 'Slot' : 'Details'}
                </span>
                {s < 4 && <span className="text-white/30 mx-1">›</span>}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* STEP 1: Select Department */}
      {step === 1 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-bold text-slate-900">Step 1: Choose Medical Specialty</h3>
            <p className="text-xs text-slate-500 mt-1">Select the clinical department for your symptoms.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {departments.map((dept) => {
              const isSelected = selectedDept === dept.name;
              return (
                <div
                  key={dept.name}
                  onClick={() => setSelectedDept(dept.name)}
                  className={`p-5 rounded-2xl border cursor-pointer transition flex items-start gap-4 ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <span className="text-3xl">{dept.icon}</span>
                  <div>
                    <h4 className="font-bold text-slate-900 text-base">{dept.name}</h4>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">{dept.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100">
            <button
              onClick={() => {
                setSelectedDoctor(deptDoctors[0] || null);
                setStep(2);
              }}
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/30 flex items-center gap-2 transition"
            >
              <span>Next: Select Doctor</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Select Doctor */}
      {step === 2 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 2: Choose Your Doctor</h3>
              <p className="text-xs text-slate-500 mt-1">Available consultants in {selectedDept}</p>
            </div>
            <button
              onClick={() => setStep(1)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {deptDoctors.map((doc) => {
              const isSelected = selectedDoctor?.id === doc.id;
              return (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDoctor(doc)}
                  className={`p-5 rounded-2xl border cursor-pointer transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-2xl bg-teal-600/10 border border-teal-200 flex items-center justify-center text-teal-800 font-extrabold text-lg">
                      <Stethoscope className="w-7 h-7 text-teal-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">{doc.name}</h4>
                      <p className="text-xs text-teal-700 font-semibold">{doc.specialty}</p>
                      <p className="text-xs text-slate-500">{doc.qualification} &bull; {doc.experienceYears} Years Experience</p>
                    </div>
                  </div>

                  <div className="text-right sm:self-center">
                    <span className="text-xs text-slate-400 block">Consultation Fee</span>
                    <span className="text-lg font-black text-slate-900">₹{doc.consultationFee}</span>
                    <span className="text-[11px] text-teal-700 block font-medium">{doc.roomNumber}</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-100">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 border border-slate-300 text-slate-600 rounded-xl text-xs font-semibold"
            >
              Back
            </button>
            <button
              disabled={!selectedDoctor}
              onClick={() => setStep(3)}
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/30 flex items-center gap-2 transition disabled:opacity-50"
            >
              <span>Next: Pick Slot</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Choose Date & Time Slot */}
      {step === 3 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 3: Choose Date & Time</h3>
              <p className="text-xs text-slate-500 mt-1">Consultation with {selectedDoctor?.name}</p>
            </div>
            <button
              onClick={() => setStep(2)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          </div>

          {/* Date Picker row */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Select Appointment Date
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {availableDates.map((item) => {
                const isSelected = selectedDate === item.iso;
                return (
                  <button
                    key={item.iso}
                    type="button"
                    onClick={() => setSelectedDate(item.iso)}
                    className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center ${
                      isSelected
                        ? 'border-teal-600 bg-teal-600 text-white shadow-md shadow-teal-600/30'
                        : 'border-slate-200 bg-slate-50 hover:bg-white text-slate-700'
                    }`}
                  >
                    <span className="text-[10px] font-bold uppercase">{item.dayName}</span>
                    <span className="text-lg font-extrabold my-0.5">{item.dateNumber}</span>
                    <span className="text-[10px] opacity-80">{item.month}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time Slots */}
          <div>
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Available Consultation Time Slots
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {timeSlots.map((slot) => {
                const isSelected = selectedTime === slot;
                return (
                  <button
                    key={slot}
                    type="button"
                    onClick={() => setSelectedTime(slot)}
                    className={`py-2.5 px-3 rounded-xl border text-xs font-semibold transition ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50 text-teal-900 ring-2 ring-teal-500/20 font-bold'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {slot}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-100">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 border border-slate-300 text-slate-600 rounded-xl text-xs font-semibold"
            >
              Back
            </button>
            <button
              onClick={() => setStep(4)}
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/30 flex items-center gap-2 transition"
            >
              <span>Next: Patient Details</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Patient Details */}
      {step === 4 && (
        <form onSubmit={handleConfirmBooking} className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Step 4: Patient Information</h3>
              <p className="text-xs text-slate-500 mt-1">Please enter accurate contact details for token issuance.</p>
            </div>
            <button
              type="button"
              onClick={() => setStep(3)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Ramesh Kumar"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Mobile Number *
              </label>
              <input
                type="tel"
                required
                placeholder="+91 98765 43210"
                value={patientPhone}
                onChange={(e) => setPatientPhone(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-teal-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Age</label>
              <input
                type="number"
                value={patientAge}
                onChange={(e) => setPatientAge(Number(e.target.value))}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Gender</label>
              <select
                value={patientGender}
                onChange={(e) => setPatientGender(e.target.value as any)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden"
              >
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email</label>
              <input
                type="email"
                placeholder="For Gmail reminder"
                value={patientEmail}
                onChange={(e) => setPatientEmail(e.target.value)}
                className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Chief Symptoms / Purpose of Consultation
            </label>
            <input
              type="text"
              placeholder="e.g. Fever since 2 days, headache, mild fatigue"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden"
            />
          </div>

          {/* Booking Summary Box */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs space-y-1.5">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Consultation Summary
            </span>
            <div className="flex justify-between text-slate-700">
              <span>Doctor:</span>
              <strong className="text-slate-900">{selectedDoctor?.name} ({selectedDept})</strong>
            </div>
            <div className="flex justify-between text-slate-700">
              <span>Date & Time:</span>
              <strong className="text-slate-900">{selectedDate} at {selectedTime}</strong>
            </div>
            <div className="flex justify-between text-slate-700">
              <span>Consultation Fee:</span>
              <strong className="text-teal-700">₹{selectedDoctor?.consultationFee} (Payable at desk)</strong>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setStep(3)}
              className="px-4 py-2 border border-slate-300 text-slate-600 rounded-xl text-xs font-semibold"
            >
              Back
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-8 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-lg shadow-teal-600/30 flex items-center gap-2 transition disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'Confirming...' : 'Confirm Appointment'}</span>
            </button>
          </div>
        </form>
      )}

      {/* STEP 5: Success & Confirmation Screen */}
      {step === 5 && bookedResult && (
        <div className="bg-white rounded-3xl border border-slate-200 p-8 shadow-xl text-center space-y-6">
          <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Booking Confirmed!
            </span>
            <h3 className="text-2xl font-black text-slate-900 mt-3">
              Your OPD Token is Ready
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Please save your token and show it to the receptionist upon clinic arrival.
            </p>
          </div>

          {/* Token Card */}
          <div className="max-w-xs mx-auto bg-gradient-to-b from-teal-50 to-emerald-50/40 p-6 rounded-2xl border-2 border-dashed border-teal-300 space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-widest text-teal-800">
              OFFICIAL CLINIC TOKEN
            </span>
            <div className="text-5xl font-black text-teal-900 tracking-tight">
              {bookedResult.token}
            </div>
            <div className="text-xs text-slate-700 pt-2 border-t border-teal-200/60">
              <div><strong>{selectedDoctor?.name}</strong></div>
              <div>{selectedDept} &bull; Room {selectedDoctor?.roomNumber}</div>
              <div className="text-slate-500 mt-1">{selectedDate} &bull; {selectedTime}</div>
            </div>
          </div>

          {/* Workspace Quick Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => syncToCalendar(bookedResult.apptId)}
              className="px-4 py-2.5 bg-blue-50 border border-blue-200 text-blue-800 rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-blue-100 transition"
            >
              <Calendar className="w-4 h-4 text-blue-600" />
              <span>Add to Google Calendar</span>
            </button>
            {patientEmail && (
              <button
                onClick={() => sendAppointmentConfirmationEmail(bookedResult.apptId)}
                className="px-4 py-2.5 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-red-100 transition"
              >
                <Mail className="w-4 h-4 text-red-600" />
                <span>Email via Gmail</span>
              </button>
            )}
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => {
                setStep(1);
                setBookedResult(null);
                setPatientName('');
                setPatientPhone('');
                setPatientEmail('');
              }}
              className="text-xs text-teal-700 font-bold hover:underline"
            >
              ← Book Another Appointment
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
