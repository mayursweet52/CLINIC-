import React, { useState } from 'react';
import { useClinic } from '../../context/ClinicContext';
import { 
  Users, 
  Search, 
  UserPlus, 
  Contact, 
  FileSpreadsheet, 
  AlertTriangle, 
  Calendar, 
  FileText, 
  Phone, 
  Mail, 
  MapPin, 
  X,
  Activity
} from 'lucide-react';
import { Patient } from '../../types/clinic';

export function PatientDirectory() {
  const {
    patients,
    appointments,
    prescriptions,
    addPatient,
    syncPatientToGoogleContacts,
    exportPatientsToSheet,
    showToast,
  } = useClinic();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);
  const [isExportingSheet, setIsExportingSheet] = useState(false);

  // New patient form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [age, setAge] = useState(35);
  const [gender, setGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [address, setAddress] = useState('');
  const [allergiesText, setAllergiesText] = useState('');
  const [conditionsText, setConditionsText] = useState('');

  const filteredPatients = patients.filter((p) => {
    return (
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.phone.includes(searchQuery) ||
      p.patientCode.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  // Handle Add Patient
  const handleCreatePatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    try {
      const newPat = await addPatient({
        organizationId: 'org-apex-01',
        name,
        phone,
        email: email || undefined,
        age: Number(age),
        gender,
        bloodGroup,
        address: address || undefined,
        allergies: allergiesText ? allergiesText.split(',').map((s) => s.trim()) : [],
        chronicConditions: conditionsText ? conditionsText.split(',').map((s) => s.trim()) : [],
      });

      setIsAddPatientModalOpen(false);
      setSelectedPatient(newPat);
      setName('');
      setPhone('');
      setEmail('');
      setAddress('');
      setAllergiesText('');
      setConditionsText('');
      showToast('Patient Enrolled', `${name} registered in Master EHR.`, 'success');
    } catch (err: any) {
      showToast('Error', err?.message || 'Failed to add patient', 'error');
    }
  };

  const handleExportSheet = async () => {
    try {
      setIsExportingSheet(true);
      const url = await exportPatientsToSheet();
      if (url) {
        window.open(url, '_blank');
      }
    } catch (err: any) {
      showToast('Export Error', err?.message, 'error');
    } finally {
      setIsExportingSheet(false);
    }
  };

  // Patient history
  const patientAppointments = selectedPatient
    ? appointments.filter((a) => a.patientId === selectedPatient.id)
    : [];
  const patientPrescriptions = selectedPatient
    ? prescriptions.filter((p) => p.patientId === selectedPatient.id)
    : [];

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="border-b border-[#e5e2db] pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-cormorant text-3xl sm:text-4xl font-semibold text-[#1a1a1a] tracking-tight">
            Patient Directory &amp; EHR
          </h2>
          <p className="text-xs uppercase tracking-[0.08em] text-[#666666] mt-1 font-medium">
            Longitudinal records, allergies, clinical encounters &bull; Google Contacts sync
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleExportSheet}
            disabled={isExportingSheet}
            className="px-4 py-2 border border-[#e5e2db] bg-white text-xs uppercase tracking-wider font-semibold text-[#1a1a1a] hover:border-[#1a1a1a] transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#4a6659]" />
            <span>{isExportingSheet ? 'Exporting...' : 'Export Directory'}</span>
          </button>
          <button
            onClick={() => setIsAddPatientModalOpen(true)}
            className="btn-editorial flex items-center gap-2"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Enroll Patient</span>
          </button>
        </div>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Patient List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#666666] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by patient name, phone, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-hairline pl-8 text-xs py-2"
            />
          </div>

          <div className="bg-white border border-[#e5e2db] divide-y divide-[#e5e2db] max-h-[640px] overflow-y-auto">
            {filteredPatients.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#666666] italic">
                No patients match the search query.
              </div>
            ) : (
              filteredPatients.map((pat) => {
                const isSelected = selectedPatient?.id === pat.id;

                return (
                  <div
                    key={pat.id}
                    onClick={() => setSelectedPatient(pat)}
                    className={`p-4 cursor-pointer transition flex items-center justify-between ${
                      isSelected ? 'bg-[#f8f7f4] border-l-4 border-l-[#1a1a1a]' : 'hover:bg-[#f8f7f4]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-[#1a1a1a]">{pat.name}</span>
                        <span className="text-[10px] font-mono border border-[#e5e2db] bg-white text-[#666666] px-1.5 py-0.5">
                          {pat.patientCode}
                        </span>
                      </div>
                      <div className="text-xs text-[#666666] mt-0.5">
                        {pat.phone} &bull; {pat.age} yrs &bull; Blood: {pat.bloodGroup}
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        syncPatientToGoogleContacts(pat.id);
                      }}
                      className="p-1.5 border border-[#e5e2db] text-[#666666] hover:text-[#1a1a1a] hover:border-[#1a1a1a] bg-white transition cursor-pointer"
                      title="Sync to Google Contacts"
                    >
                      <Contact className="w-3.5 h-3.5 text-[#4a6659]" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right: Selected Patient Clinical Chart */}
        <div className="lg:col-span-7 space-y-6">
          {selectedPatient ? (
            <div className="bg-white border border-[#e5e2db] shadow-xs overflow-hidden">
              {/* Profile Card Header */}
              <div className="p-6 border-b border-[#e5e2db] bg-[#f8f7f4]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">{selectedPatient.name}</h3>
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 border border-[#e5e2db] bg-white text-[#666666]">
                        {selectedPatient.patientCode}
                      </span>
                    </div>
                    <div className="text-xs text-[#666666] mt-1 flex flex-wrap items-center gap-3">
                      <span>{selectedPatient.age} Years &bull; {selectedPatient.gender}</span>
                      <span>Blood Group: <strong className="text-[#1a1a1a]">{selectedPatient.bloodGroup}</strong></span>
                      <span>Phone: {selectedPatient.phone}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => syncPatientToGoogleContacts(selectedPatient.id)}
                    className="btn-editorial text-xs py-1.5 px-3 flex items-center gap-1.5 self-start"
                  >
                    <Contact className="w-3.5 h-3.5" />
                    <span>Sync Google Contact</span>
                  </button>
                </div>
              </div>

              {/* Clinical Attributes Banner */}
              <div className="p-6 border-b border-[#e5e2db] grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#f8f7f4]">
                <div className="bg-white p-4 border border-[#e5e2db]">
                  <span className="stat-label block mb-1">
                    Known Drug &amp; Food Allergies
                  </span>
                  {selectedPatient.allergies.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {selectedPatient.allergies.map((allg, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 border border-[#e5e2db] bg-white text-[#a83232] text-xs font-semibold flex items-center gap-1"
                        >
                          <AlertTriangle className="w-3 h-3 text-[#a83232]" /> {allg}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-[#666666]">No known allergies reported</span>
                  )}
                </div>

                <div className="bg-white p-4 border border-[#e5e2db]">
                  <span className="stat-label block mb-1">
                    Chronic Medical Conditions
                  </span>
                  {selectedPatient.chronicConditions.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {selectedPatient.chronicConditions.map((cond, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 border border-[#e5e2db] bg-white text-[#1a1a1a] text-xs font-medium"
                        >
                          {cond}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-[#666666]">None recorded</span>
                  )}
                </div>
              </div>

              {/* History Tabs (Past Consultations & Prescriptions) */}
              <div className="p-6 sm:p-8 space-y-6">
                <div>
                  <h4 className="form-section-label flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[#4a6659]" />
                    <span>Past OPD Encounters ({patientAppointments.length})</span>
                  </h4>
                  {patientAppointments.length === 0 ? (
                    <p className="text-xs text-[#666666] italic">No past visits recorded.</p>
                  ) : (
                    <div className="divide-y divide-[#e5e2db] border border-[#e5e2db] text-xs">
                      {patientAppointments.map((appt) => (
                        <div key={appt.id} className="p-3 px-4 flex items-center justify-between">
                          <div>
                            <span className="font-semibold text-[#1a1a1a] mr-2">Token {appt.tokenNumber}</span>
                            <span className="text-[#666666]">{appt.appointmentDate} at {appt.appointmentTime}</span>
                            <span className="text-[#666666] block mt-0.5">Doctor: {appt.doctorName} &bull; Reason: {appt.reason || 'General Checkup'}</span>
                          </div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#4a6659]">
                            {appt.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="form-section-label flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-[#4a6659]" />
                    <span>E-Prescription Records ({patientPrescriptions.length})</span>
                  </h4>
                  {patientPrescriptions.length === 0 ? (
                    <p className="text-xs text-[#666666] italic">No prescriptions issued yet.</p>
                  ) : (
                    <div className="space-y-3">
                      {patientPrescriptions.map((rx) => (
                        <div key={rx.id} className="p-4 border border-[#e5e2db] bg-[#f8f7f4] text-xs space-y-2">
                          <div className="flex justify-between font-semibold text-[#1a1a1a]">
                            <span>{rx.diagnosis}</span>
                            <span className="text-[#666666] font-normal">{rx.createdAt.split('T')[0]}</span>
                          </div>
                          <div className="text-[#666666]">Prescribed by {rx.doctorName}</div>
                          <div className="flex flex-wrap gap-2 pt-1">
                            {rx.medicines.map((m, i) => (
                              <span key={i} className="bg-white border border-[#e5e2db] px-2 py-0.5 text-xs text-[#1a1a1a]">
                                {m.medicineName} ({m.dosage}) &bull; {m.frequency}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#e5e2db] p-16 text-center text-[#666666] shadow-xs">
              <Users className="w-10 h-10 mx-auto text-[#666666] mb-3 opacity-40" />
              <h4 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Select a Patient</h4>
              <p className="text-xs text-[#666666] mt-1">
                Choose a patient on the left to inspect longitudinal health history and sync to Google Contacts.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* REGISTER PATIENT MODAL */}
      {isAddPatientModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-2xs p-4 overflow-y-auto">
          <div className="bg-white max-w-lg w-full border border-[#e5e2db] p-8 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-[#e5e2db] pb-4">
              <div>
                <h3 className="font-cormorant text-2xl font-semibold text-[#1a1a1a]">Enroll New Patient</h3>
                <p className="text-[10px] uppercase tracking-wider text-[#666666]">Enrolls into Master EHR and Google Directory</p>
              </div>
              <button onClick={() => setIsAddPatientModalOpen(false)} className="text-[#666666] hover:text-[#1a1a1a] cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePatient} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="field">
                  <label>Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="Patient Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="+91..."
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="input-hairline"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="field">
                  <label>Age</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(Number(e.target.value))}
                    className="input-hairline"
                  />
                </div>
                <div className="field">
                  <label>Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="MALE">Male</option>
                    <option value="FEMALE">Female</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
                <div className="field">
                  <label>Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="input-hairline cursor-pointer"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
              </div>

              <div className="field">
                <label>Email Address</label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="field">
                <label>Allergies (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Penicillin, Sulfa drugs, Aspirin"
                  value={allergiesText}
                  onChange={(e) => setAllergiesText(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="field">
                <label>Chronic Conditions (comma separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Hypertension, Type 2 Diabetes"
                  value={conditionsText}
                  onChange={(e) => setConditionsText(e.target.value)}
                  className="input-hairline"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#e5e2db]">
                <button
                  type="button"
                  onClick={() => setIsAddPatientModalOpen(false)}
                  className="px-4 py-2 text-xs uppercase tracking-wider font-semibold text-[#666666] hover:text-[#1a1a1a] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn-editorial"
                >
                  Enroll Patient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
