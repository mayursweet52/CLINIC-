import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  updateDoc, 
  writeBatch,
  query,
  orderBy 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { 
  HealthAppointment, 
  Patient, 
  Prescription, 
  InventoryItem, 
  Billing, 
  AuditLog, 
  UserRole, 
  DoctorProfile, 
  DoctorTimeOff,
  ApptStatus,
  PaymentStatus 
} from '../types/clinic';
import { 
  INITIAL_DOCTORS, 
  INITIAL_PATIENTS, 
  INITIAL_APPOINTMENTS, 
  INITIAL_INVENTORY, 
  INITIAL_PRESCRIPTIONS, 
  INITIAL_BILLINGS 
} from '../lib/seedData';
import { 
  requestGoogleWorkspaceToken, 
  signInGoogleWorkspace,
  createGoogleCalendarEvent, 
  exportToGoogleSheet, 
  sendGmailMessage, 
  createGoogleContact 
} from '../lib/workspace';

interface ClinicContextType {
  // Current user & role
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  activeDoctorId: string;
  setActiveDoctorId: (id: string) => void;
  doctors: DoctorProfile[];
  
  // Real-time state collections
  appointments: HealthAppointment[];
  patients: Patient[];
  prescriptions: Prescription[];
  inventory: InventoryItem[];
  billings: Billing[];
  auditLogs: AuditLog[];
  doctorLeaves: DoctorTimeOff[];
  
  // Real-time sync indicator
  isRealtimeConnected: boolean;
  lastSyncTime: Date;
  
  // Core workflows
  bookAppointment: (data: {
    patientName: string;
    patientPhone: string;
    patientEmail?: string;
    patientAge: number;
    patientGender: string;
    doctorId: string;
    appointmentDate: string;
    appointmentTime: string;
    reason: string;
    syncCalendar?: boolean;
    sendEmail?: boolean;
  }) => Promise<{ appointment: HealthAppointment; token: string }>;

  checkInPatient: (appointmentId: string) => Promise<void>;
  startConsultation: (appointmentId: string) => Promise<void>;
  completeConsultation: (params: {
    appointmentId: string;
    diagnosis: string;
    symptoms: string[];
    vitals?: Prescription['vitals'];
    medicines: Prescription['medicines'];
    advice?: string;
    followUpDate?: string;
    consultationFee?: number;
    syncCalendar?: boolean;
    sendEmail?: boolean;
  }) => Promise<void>;

  dispensePrescription: (prescriptionId: string, items: { medicineId: string; quantity: number }[]) => Promise<void>;
  updateBillPayment: (billId: string, status: PaymentStatus, method: 'CASH' | 'UPI' | 'CARD' | 'ONLINE') => Promise<void>;
  markDoctorLeave: (doctorId: string, date: string, reason: string) => Promise<{ cancelledCount: number }>;
  
  // Patient & Inventory management
  addPatient: (patientData: Omit<Patient, 'id' | 'patientCode' | 'createdAt'>) => Promise<Patient>;
  addInventoryItem: (item: Omit<InventoryItem, 'id'>) => Promise<void>;
  updateInventoryStock: (id: string, delta: number) => Promise<void>;
  
  // Workspace Integrations
  workspaceToken: string | null;
  connectGoogleWorkspace: () => Promise<string | null>;
  disconnectGoogleWorkspace: () => void;
  syncToCalendar: (appointmentId: string) => Promise<{ eventId: string; htmlLink: string } | null>;
  syncPatientToGoogleContacts: (patientId: string) => Promise<{ resourceName: string } | null>;
  exportAppointmentsToSheet: () => Promise<string | null>;
  exportBillingToSheet: () => Promise<string | null>;
  exportPatientsToSheet: () => Promise<string | null>;
  sendAppointmentConfirmationEmail: (appointmentId: string) => Promise<string | null>;
  sendPrescriptionEmail: (prescriptionId: string) => Promise<string | null>;

  // System actions
  seedDefaultData: () => Promise<void>;
  activeToast: { title: string; message: string; type: 'success' | 'info' | 'warning' | 'error' } | null;
  dismissToast: () => void;
  showToast: (title: string, message: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

const ClinicContext = createContext<ClinicContextType | null>(null);

export function ClinicProvider({ children }: { children: React.ReactNode }) {
  const [currentRole, setCurrentRole] = useState<UserRole>('DOCTOR');
  const [activeDoctorId, setActiveDoctorId] = useState<string>('doc-001');
  const [doctors] = useState<DoctorProfile[]>(INITIAL_DOCTORS);
  
  // Real-time state
  const [appointments, setAppointments] = useState<HealthAppointment[]>(INITIAL_APPOINTMENTS);
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(INITIAL_PRESCRIPTIONS);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [billings, setBillings] = useState<Billing[]>(INITIAL_BILLINGS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [doctorLeaves, setDoctorLeaves] = useState<DoctorTimeOff[]>([]);
  
  const [isRealtimeConnected, setIsRealtimeConnected] = useState<boolean>(true);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  
  // Google Workspace Token
  const [workspaceToken, setWorkspaceToken] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('clinic_gw_token');
    }
    return null;
  });

  // Toast notifications
  const [activeToast, setActiveToast] = useState<{
    title: string;
    message: string;
    type: 'success' | 'info' | 'warning' | 'error';
  } | null>(null);

  const showToast = (
    title: string,
    message: string,
    type: 'success' | 'info' | 'warning' | 'error' = 'info'
  ) => {
    setActiveToast({ title, message, type });
    setTimeout(() => {
      setActiveToast((prev) => (prev?.title === title ? null : prev));
    }, 4500);
  };

  const dismissToast = () => setActiveToast(null);

  // Helper for audit logging
  const logAudit = async (action: string, resource: string, details: string, resourceId?: string) => {
    const newLog: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: activeDoctorId || 'system',
      userName: currentRole === 'DOCTOR' 
        ? doctors.find((d) => d.id === activeDoctorId)?.name || 'Dr. Ananya Sharma' 
        : currentRole,
      role: currentRole,
      action,
      resource,
      resourceId,
      details,
      timestamp: new Date().toISOString(),
    };

    setAuditLogs((prev) => [newLog, ...prev.slice(0, 49)]);

    try {
      await setDoc(doc(db, 'auditLogs', newLog.id), newLog);
    } catch {
      // safe fallback
    }
  };

  // Google Workspace auth handler
  const connectGoogleWorkspace = async (): Promise<string | null> => {
    try {
      const res = await signInGoogleWorkspace();
      if (res?.token) {
        setWorkspaceToken(res.token);
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('clinic_gw_token', res.token);
        }
        showToast(
          'Google Workspace Linked!',
          'Google Calendar, Google Sheets, Gmail, and Google Contacts are now authorized.',
          'success'
        );
        logAudit('oauth.connect', 'Workspace', 'Google Workspace OAuth token granted');
        return res.token;
      } else {
        showToast('Google Workspace Connection', 'Sign-in prompt cancelled or dismissed.', 'info');
        return null;
      }
    } catch (err: any) {
      console.error('Failed to link Google Workspace:', err);
      showToast('Google Link Note', err?.message || 'Could not complete authorization. Check popup settings.', 'warning');
      return null;
    }
  };

  const ensureWorkspaceToken = async (): Promise<string | null> => {
    if (workspaceToken) return workspaceToken;
    showToast('Connecting Google Workspace...', 'Opening Google Authorization popup.', 'info');
    const token = await connectGoogleWorkspace();
    if (!token) {
      showToast('Authorization Required', 'Please connect your Google account to sync with Google Workspace.', 'warning');
      return null;
    }
    return token;
  };

  const disconnectGoogleWorkspace = () => {
    setWorkspaceToken(null);
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('clinic_gw_token');
    }
    showToast('Workspace Disconnected', 'Google Workspace token cleared.', 'info');
  };

  // Setup Firestore real-time listeners
  useEffect(() => {
    const unsubscribes: (() => void)[] = [];

    try {
      // 1. Appointments listener
      const apptQuery = query(collection(db, 'appointments'), orderBy('createdAt', 'desc'));
      const unsubAppts = onSnapshot(
        apptQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => d.data() as HealthAppointment);
            setAppointments((prev) => {
              const map = new Map<string, HealthAppointment>();
              INITIAL_APPOINTMENTS.forEach((a) => map.set(a.id, a));
              prev.forEach((a) => map.set(a.id, a));
              items.forEach((a) => map.set(a.id, a));
              return Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
              );
            });
            setIsRealtimeConnected(true);
            setLastSyncTime(new Date());
          }
        },
        (error) => {
          console.warn('Firestore appointments subscription error, using state cache:', error);
          setIsRealtimeConnected(false);
        }
      );
      unsubscribes.push(unsubAppts);

      // 2. Patients listener
      const patQuery = query(collection(db, 'patients'), orderBy('createdAt', 'desc'));
      const unsubPatients = onSnapshot(
        patQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => d.data() as Patient);
            setPatients((prev) => {
              const map = new Map<string, Patient>();
              INITIAL_PATIENTS.forEach((p) => map.set(p.id, p));
              prev.forEach((p) => map.set(p.id, p));
              items.forEach((p) => map.set(p.id, p));
              return Array.from(map.values());
            });
          }
        },
        (err) => console.warn('Firestore patients error:', err)
      );
      unsubscribes.push(unsubPatients);

      // 3. Prescriptions listener
      const rxQuery = query(collection(db, 'prescriptions'), orderBy('createdAt', 'desc'));
      const unsubRx = onSnapshot(
        rxQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => d.data() as Prescription);
            setPrescriptions((prev) => {
              const map = new Map<string, Prescription>();
              INITIAL_PRESCRIPTIONS.forEach((r) => map.set(r.id, r));
              prev.forEach((r) => map.set(r.id, r));
              items.forEach((r) => map.set(r.id, r));
              return Array.from(map.values());
            });
          }
        },
        (err) => console.warn('Firestore prescriptions error:', err)
      );
      unsubscribes.push(unsubRx);

      // 4. Inventory listener
      const invQuery = query(collection(db, 'inventory'));
      const unsubInv = onSnapshot(
        invQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => d.data() as InventoryItem);
            setInventory((prev) => {
              const map = new Map<string, InventoryItem>();
              INITIAL_INVENTORY.forEach((i) => map.set(i.id, i));
              prev.forEach((i) => map.set(i.id, i));
              items.forEach((i) => map.set(i.id, i));
              return Array.from(map.values());
            });
          }
        },
        (err) => console.warn('Firestore inventory error:', err)
      );
      unsubscribes.push(unsubInv);

      // 5. Billing listener
      const billQuery = query(collection(db, 'billings'), orderBy('createdAt', 'desc'));
      const unsubBills = onSnapshot(
        billQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            const items = snapshot.docs.map((d) => d.data() as Billing);
            setBillings((prev) => {
              const map = new Map<string, Billing>();
              INITIAL_BILLINGS.forEach((b) => map.set(b.id, b));
              prev.forEach((b) => map.set(b.id, b));
              items.forEach((b) => map.set(b.id, b));
              return Array.from(map.values());
            });
          }
        },
        (err) => console.warn('Firestore billing error:', err)
      );
      unsubscribes.push(unsubBills);

      // 6. Audit logs listener
      const auditQuery = query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'));
      const unsubAudit = onSnapshot(
        auditQuery,
        (snapshot) => {
          if (!snapshot.empty) {
            setAuditLogs(snapshot.docs.map((d) => d.data() as AuditLog));
          }
        },
        (err) => console.warn('Firestore audit error:', err)
      );
      unsubscribes.push(unsubAudit);
    } catch (e) {
      console.warn('Firestore connection caught error:', e);
      setIsRealtimeConnected(false);
    }

    return () => {
      unsubscribes.forEach((unsub) => unsub());
    };
  }, []);

  // One-time default seeding helper
  const seedDefaultData = async () => {
    try {
      showToast('Seeding Clinic Data...', 'Uploading initial clinical records to Firestore.', 'info');
      const batch = writeBatch(db);

      INITIAL_PATIENTS.forEach((p) => {
        batch.set(doc(db, 'patients', p.id), p);
      });
      INITIAL_APPOINTMENTS.forEach((a) => {
        batch.set(doc(db, 'appointments', a.id), a);
      });
      INITIAL_INVENTORY.forEach((i) => {
        batch.set(doc(db, 'inventory', i.id), i);
      });
      INITIAL_PRESCRIPTIONS.forEach((r) => {
        batch.set(doc(db, 'prescriptions', r.id), r);
      });
      INITIAL_BILLINGS.forEach((b) => {
        batch.set(doc(db, 'billings', b.id), b);
      });

      await batch.commit();
      showToast('Clinic Seeded', 'Demo records active across Firestore.', 'success');
    } catch (err: any) {
      console.error('Error seeding data:', err);
      showToast('Seeding Note', 'Operating with cached clinical datasets.', 'info');
    }
  };

  // Workflow 1: Book Appointment
  const bookAppointment = async (data: {
    patientName: string;
    patientPhone: string;
    patientEmail?: string;
    patientAge: number;
    patientGender: string;
    doctorId: string;
    appointmentDate: string;
    appointmentTime: string;
    reason: string;
    syncCalendar?: boolean;
    sendEmail?: boolean;
  }) => {
    const todayStr = new Date().toISOString().split('T')[0];
    const apptDate = data.appointmentDate || todayStr;
    const apptTime = data.appointmentTime || '10:30 AM';
    const doctor = doctors.find((d) => d.id === data.doctorId) || doctors[0];
    
    // Check if patient already exists by phone
    let patient = patients.find((p) => p.phone === data.patientPhone);
    if (!patient) {
      const newPatientCode = `AMC-2026-${String(patients.length + 101).padStart(4, '0')}`;
      patient = {
        id: `pat-${Date.now()}`,
        organizationId: 'org-apex-01',
        patientCode: newPatientCode,
        name: data.patientName,
        phone: data.patientPhone,
        email: data.patientEmail,
        age: Number(data.patientAge) || 30,
        gender: (data.patientGender || 'MALE') as any,
        bloodGroup: 'Not recorded',
        allergies: [],
        chronicConditions: [],
        createdAt: new Date().toISOString(),
      };

      setPatients((prev) => [patient!, ...prev]);
      try {
        await setDoc(doc(db, 'patients', patient.id), patient);
      } catch (e) {
        console.warn('Patient save fallback:', e);
      }
    }

    // Generate Token Number e.g. Q-105
    const existingTokens = appointments
      .filter((a) => a.appointmentDate === apptDate)
      .map((a) => {
        const num = parseInt(a.tokenNumber.replace('Q-', ''), 10);
        return isNaN(num) ? 100 : num;
      });
    const nextTokenNum = existingTokens.length > 0 ? Math.max(...existingTokens) + 1 : 101;
    const tokenNumber = `Q-${nextTokenNum}`;

    const newAppointment: HealthAppointment = {
      id: `appt-${Date.now()}`,
      organizationId: 'org-apex-01',
      patientId: patient.id,
      patientName: patient.name,
      patientPhone: patient.phone,
      patientAge: patient.age,
      patientGender: patient.gender,
      doctorId: doctor.id,
      doctorName: doctor.name,
      department: doctor.department,
      appointmentDate: apptDate,
      appointmentTime: apptTime,
      tokenNumber,
      status: 'SCHEDULED',
      reason: data.reason || 'General Consultation',
      createdAt: new Date().toISOString(),
    };

    setAppointments((prev) => [newAppointment, ...prev]);

    try {
      await setDoc(doc(db, 'appointments', newAppointment.id), newAppointment);
    } catch (e) {
      console.warn('Appointment save fallback:', e);
    }

    logAudit('appointment.create', 'HealthAppointment', `Booked token ${tokenNumber} for ${patient.name} (${doctor.name})`, newAppointment.id);
    showToast('Appointment Confirmed!', `Token: ${tokenNumber} booked for ${patient.name} with ${doctor.name}`, 'success');

    // Optional Google Calendar sync
    if (data.syncCalendar && workspaceToken) {
      try {
        const cal = await createGoogleCalendarEvent(workspaceToken, {
          patientName: patient.name,
          doctorName: doctor.name,
          department: doctor.department,
          date: data.appointmentDate,
          time: data.appointmentTime,
          tokenNumber,
          reason: data.reason,
        });
        newAppointment.googleCalendarEventId = cal.eventId;
        showToast('Google Calendar Synced', `Event added to Google Calendar.`, 'success');
      } catch (err) {
        console.warn('Google Calendar auto-sync error:', err);
      }
    }

    // Optional Gmail confirmation
    if (data.sendEmail && data.patientEmail && workspaceToken) {
      try {
        await sendGmailMessage(workspaceToken, {
          to: data.patientEmail,
          subject: `Appointment Confirmed: Token ${tokenNumber} at Apex Metro Clinic`,
          bodyHtml: `
            <p>Dear <strong>${patient.name}</strong>,</p>
            <p>Your appointment has been successfully confirmed at <strong>Apex Metro Clinic</strong>.</p>
            <div style="background: #f1f5f9; padding: 16px; border-radius: 6px; margin: 16px 0;">
              <p style="margin: 4px 0;"><strong>Token Number:</strong> <span style="font-size: 18px; color: #0d9488;">${tokenNumber}</span></p>
              <p style="margin: 4px 0;"><strong>Doctor:</strong> ${doctor.name} (${doctor.specialty})</p>
              <p style="margin: 4px 0;"><strong>Room:</strong> ${doctor.roomNumber}</p>
              <p style="margin: 4px 0;"><strong>Date:</strong> ${data.appointmentDate}</p>
              <p style="margin: 4px 0;"><strong>Time:</strong> ${data.appointmentTime}</p>
            </div>
            <p>Please present this token at the reception desk 10 minutes prior to your time.</p>
          `,
        });
        showToast('Confirmation Email Sent', `Sent confirmation to ${data.patientEmail} via Gmail.`, 'success');
      } catch (err) {
        console.warn('Gmail confirmation error:', err);
      }
    }

    return { appointment: newAppointment, token: tokenNumber };
  };

  // Workflow 2: Reception Check-In
  const checkInPatient = async (appointmentId: string) => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === appointmentId ? { ...a, status: 'ARRIVED', checkedInAt: timeNow } : a
      )
    );

    const appt = appointments.find((a) => a.id === appointmentId);
    showToast('Patient Checked In', `${appt?.patientName || 'Patient'} (Token ${appt?.tokenNumber}) marked ARRIVED in waiting area.`, 'info');
    logAudit('patient.checkin', 'HealthAppointment', `Patient arrived: ${appt?.patientName} (${appt?.tokenNumber})`, appointmentId);

    try {
      await updateDoc(doc(db, 'appointments', appointmentId), {
        status: 'ARRIVED',
        checkedInAt: timeNow,
      });
    } catch (e) {
      console.warn('Check-in update fallback:', e);
    }
  };

  // Workflow 3: Start Consultation
  const startConsultation = async (appointmentId: string) => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    setAppointments((prev) =>
      prev.map((a) =>
        a.id === appointmentId
          ? { ...a, status: 'IN_CONSULTATION', consultationStartedAt: timeNow }
          : a
      )
    );

    const appt = appointments.find((a) => a.id === appointmentId);
    showToast('Consultation Started', `Now consulting ${appt?.patientName} (${appt?.tokenNumber}).`, 'info');
    logAudit('consultation.start', 'HealthAppointment', `Started consultation for ${appt?.patientName}`, appointmentId);

    try {
      await updateDoc(doc(db, 'appointments', appointmentId), {
        status: 'IN_CONSULTATION',
        consultationStartedAt: timeNow,
      });
    } catch (e) {
      console.warn('Consultation start fallback:', e);
    }
  };

  // Workflow 4: Complete Consultation
  const completeConsultation = async (params: {
    appointmentId: string;
    diagnosis: string;
    symptoms: string[];
    vitals?: Prescription['vitals'];
    medicines: Prescription['medicines'];
    advice?: string;
    followUpDate?: string;
    consultationFee?: number;
    syncCalendar?: boolean;
    sendEmail?: boolean;
  }) => {
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const appt = appointments.find((a) => a.id === params.appointmentId);
    if (!appt) return;

    const doctor = doctors.find((d) => d.id === appt.doctorId) || doctors[0];
    const fee = params.consultationFee ?? doctor.consultationFee;

    // 1. Update Appointment
    setAppointments((prev) =>
      prev.map((a) =>
        a.id === params.appointmentId
          ? { ...a, status: 'COMPLETED', completedAt: timeNow }
          : a
      )
    );

    // 2. Generate E-Prescription
    const newPrescription: Prescription = {
      id: `rx-${Date.now()}`,
      organizationId: 'org-apex-01',
      appointmentId: appt.id,
      patientId: appt.patientId,
      patientName: appt.patientName,
      doctorId: doctor.id,
      doctorName: doctor.name,
      diagnosis: params.diagnosis,
      symptoms: params.symptoms,
      vitals: params.vitals,
      medicines: params.medicines,
      advice: params.advice,
      followUpDate: params.followUpDate,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };

    setPrescriptions((prev) => [newPrescription, ...prev]);

    // 3. Generate Billing Invoice
    const invoiceNumber = `INV-2026-${String(billings.length + 101).padStart(4, '0')}`;
    const newBill: Billing = {
      id: `bill-${Date.now()}`,
      organizationId: 'org-apex-01',
      appointmentId: appt.id,
      patientId: appt.patientId,
      patientName: appt.patientName,
      invoiceNumber,
      consultationFee: fee,
      medicineCharges: 0, // updated when pharmacy dispenses
      labCharges: 0,
      discount: 0,
      totalAmount: fee,
      paymentStatus: 'PENDING',
      createdAt: new Date().toISOString(),
    };

    setBillings((prev) => [newBill, ...prev]);

    showToast(
      'Consultation Completed',
      `Prescription sent to Pharmacy. Invoice ${invoiceNumber} created for ₹${fee}.`,
      'success'
    );
    logAudit('consultation.complete', 'HealthAppointment', `Completed consultation for ${appt.patientName}. Rx: ${newPrescription.id}, Bill: ${invoiceNumber}`, appt.id);

    try {
      await updateDoc(doc(db, 'appointments', appt.id), {
        status: 'COMPLETED',
        completedAt: timeNow,
      });
      await setDoc(doc(db, 'prescriptions', newPrescription.id), newPrescription);
      await setDoc(doc(db, 'billings', newBill.id), newBill);
    } catch (e) {
      console.warn('Consultation complete persistence fallback:', e);
    }

    // Google Calendar Follow-up Sync
    if (params.syncCalendar && params.followUpDate && workspaceToken) {
      try {
        await createGoogleCalendarEvent(workspaceToken, {
          patientName: appt.patientName,
          doctorName: doctor.name,
          department: doctor.department,
          date: params.followUpDate,
          time: '11:00 AM',
          tokenNumber: `FollowUp-${appt.tokenNumber}`,
          reason: `Follow-up visit for ${params.diagnosis}`,
        });
        showToast('Follow-up Calendar Synced', `Added to Google Calendar for ${params.followUpDate}`, 'success');
      } catch (err) {
        console.warn('Calendar follow-up error:', err);
      }
    }

    // Gmail send prescription & bill
    if (params.sendEmail && appt.patientPhone && workspaceToken) {
      const patient = patients.find((p) => p.id === appt.patientId);
      if (patient?.email) {
        sendPrescriptionEmail(newPrescription.id).catch(console.warn);
      }
    }
  };

  // Workflow 5: Dispense Prescription
  const dispensePrescription = async (prescriptionId: string, items: { medicineId: string; quantity: number }[]) => {
    const rx = prescriptions.find((r) => r.id === prescriptionId);
    if (!rx) return;

    let totalMedCharges = 0;

    // Deduct stock in inventory
    setInventory((prev) =>
      prev.map((inv) => {
        const itemToDispense = items.find((i) => i.medicineId === inv.id);
        if (itemToDispense) {
          totalMedCharges += inv.unitPrice * itemToDispense.quantity;
          const updatedQty = Math.max(0, inv.quantity - itemToDispense.quantity);
          return { ...inv, quantity: updatedQty };
        }
        return inv;
      })
    );

    // Update prescription status
    setPrescriptions((prev) =>
      prev.map((r) =>
        r.id === prescriptionId
          ? { ...r, status: 'DISPENSED', dispensedAt: new Date().toISOString() }
          : r
      )
    );

    // Update billing with medicine charges
    setBillings((prev) =>
      prev.map((b) => {
        if (b.appointmentId === rx.appointmentId) {
          const updatedTotal = b.consultationFee + totalMedCharges + b.labCharges - b.discount;
          return {
            ...b,
            medicineCharges: totalMedCharges,
            totalAmount: updatedTotal,
          };
        }
        return b;
      })
    );

    showToast('Prescription Dispensed', `Medicines deducted from stock. Total charges: ₹${totalMedCharges.toFixed(2)}`, 'success');
    logAudit('pharmacy.dispense', 'Prescription', `Dispensed medicines for ${rx.patientName}`, prescriptionId);

    try {
      await updateDoc(doc(db, 'prescriptions', prescriptionId), {
        status: 'DISPENSED',
        dispensedAt: new Date().toISOString(),
      });
      // update billing in Firestore
      const bill = billings.find((b) => b.appointmentId === rx.appointmentId);
      if (bill) {
        await updateDoc(doc(db, 'billings', bill.id), {
          medicineCharges: totalMedCharges,
          totalAmount: bill.consultationFee + totalMedCharges + bill.labCharges - bill.discount,
        });
      }
    } catch (e) {
      console.warn('Dispense persistence fallback:', e);
    }
  };

  // Workflow 6: Update Bill Payment
  const updateBillPayment = async (
    billId: string,
    status: PaymentStatus,
    method: 'CASH' | 'UPI' | 'CARD' | 'ONLINE'
  ) => {
    const paidAt = new Date().toISOString();

    setBillings((prev) =>
      prev.map((b) =>
        b.id === billId
          ? { ...b, paymentStatus: status, paymentMethod: method, paidAt }
          : b
      )
    );

    const bill = billings.find((b) => b.id === billId);
    showToast('Payment Recorded', `Invoice ${bill?.invoiceNumber} marked ${status} via ${method}.`, 'success');
    logAudit('bill.payment', 'Billing', `Payment received: ₹${bill?.totalAmount} via ${method}`, billId);

    try {
      await updateDoc(doc(db, 'billings', billId), {
        paymentStatus: status,
        paymentMethod: method,
        paidAt,
      });
    } catch (e) {
      console.warn('Payment update fallback:', e);
    }
  };

  // Workflow 7: Doctor Leave
  const markDoctorLeave = async (doctorId: string, date: string, reason: string) => {
    const doctor = doctors.find((d) => d.id === doctorId) || doctors[0];
    const newLeave: DoctorTimeOff = {
      id: `leave-${Date.now()}`,
      doctorId: doctor.id,
      doctorName: doctor.name,
      date,
      reason,
      createdAt: new Date().toISOString(),
    };

    setDoctorLeaves((prev) => [newLeave, ...prev]);

    // Find and auto-cancel conflicting appointments
    let cancelledCount = 0;
    setAppointments((prev) =>
      prev.map((a) => {
        if (
          a.doctorId === doctorId &&
          a.appointmentDate === date &&
          (a.status === 'SCHEDULED' || a.status === 'ARRIVED')
        ) {
          cancelledCount++;
          return {
            ...a,
            status: 'CANCELLED',
            notes: `Auto-cancelled: Doctor on leave (${reason})`,
          };
        }
        return a;
      })
    );

    showToast(
      'Doctor Leave Registered',
      `${doctor.name} on leave on ${date}. ${cancelledCount} conflicting appointment(s) rescheduled/cancelled.`,
      'warning'
    );
    logAudit('doctor.leave', 'DoctorTimeOff', `Leave marked for ${doctor.name} on ${date}: ${reason}`, newLeave.id);

    return { cancelledCount };
  };

  // Patient directory addition
  const addPatient = async (patientData: Omit<Patient, 'id' | 'patientCode' | 'createdAt'>): Promise<Patient> => {
    const newCode = `AMC-2026-${String(patients.length + 101).padStart(4, '0')}`;
    const newPat: Patient = {
      ...patientData,
      id: `pat-${Date.now()}`,
      organizationId: 'org-apex-01',
      patientCode: newCode,
      createdAt: new Date().toISOString(),
    };

    setPatients((prev) => [newPat, ...prev]);
    try {
      await setDoc(doc(db, 'patients', newPat.id), newPat);
    } catch (e) {
      console.warn('Patient save fallback:', e);
    }

    showToast('Patient Registered', `${newPat.name} registered with Code ${newCode}`, 'success');
    logAudit('patient.create', 'Patient', `Created patient ${newPat.name} (${newCode})`, newPat.id);
    return newPat;
  };

  // Inventory additions & stock update
  const addInventoryItem = async (item: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...item,
      id: `inv-${Date.now()}`,
    };
    setInventory((prev) => [newItem, ...prev]);
    try {
      await setDoc(doc(db, 'inventory', newItem.id), newItem);
    } catch (e) {
      console.warn('Inventory save fallback:', e);
    }
    showToast('Medicine Added', `${newItem.medicineName} added to pharmacy inventory.`, 'success');
    logAudit('inventory.create', 'InventoryItem', `Added medicine ${newItem.medicineName}`, newItem.id);
  };

  const updateInventoryStock = async (id: string, delta: number) => {
    setInventory((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newQty = Math.max(0, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
    const item = inventory.find((i) => i.id === id);
    showToast('Stock Adjusted', `${item?.medicineName}: ${delta > 0 ? `+${delta}` : delta} units.`, 'info');
  };

  // Workspace actions
  const syncToCalendar = async (appointmentId: string): Promise<{ eventId: string; htmlLink: string } | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    const appt = appointments.find((a) => a.id === appointmentId);
    if (!appt) {
      showToast('Appointment Not Found', 'Could not find appointment to sync.', 'error');
      return null;
    }

    try {
      const result = await createGoogleCalendarEvent(token, {
        patientName: appt.patientName,
        doctorName: appt.doctorName,
        department: appt.department,
        date: appt.appointmentDate,
        time: appt.appointmentTime,
        tokenNumber: appt.tokenNumber,
        reason: appt.reason,
      });

      setAppointments((prev) =>
        prev.map((a) => (a.id === appointmentId ? { ...a, googleCalendarEventId: result.eventId } : a))
      );
      showToast('Synced to Google Calendar', `Event created for Token ${appt.tokenNumber}.`, 'success');
      logAudit('calendar.sync', 'GoogleCalendar', `Synced appointment ${appt.tokenNumber} to Google Calendar`, appointmentId);
      return result;
    } catch (err: any) {
      console.error('Google Calendar error:', err);
      showToast('Calendar Sync Error', err?.message || 'Could not sync event to Google Calendar.', 'error');
      return null;
    }
  };

  const syncPatientToGoogleContacts = async (patientId: string): Promise<{ resourceName: string } | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    const patient = patients.find((p) => p.id === patientId);
    if (!patient) {
      showToast('Patient Not Found', 'Could not find patient.', 'error');
      return null;
    }

    try {
      const result = await createGoogleContact(token, {
        name: patient.name,
        phone: patient.phone,
        email: patient.email,
        patientCode: patient.patientCode,
        bloodGroup: patient.bloodGroup,
      });

      setPatients((prev) =>
        prev.map((p) => (p.id === patientId ? { ...p, syncedToGoogleContacts: true } : p))
      );
      showToast('Patient Synced to Contacts', `${patient.name} added to your Google Contacts.`, 'success');
      logAudit('contacts.sync', 'GoogleContacts', `Synced patient ${patient.name} (${patient.patientCode}) to Google Contacts`, patientId);
      return result;
    } catch (err: any) {
      console.error('Google Contacts error:', err);
      showToast('Contacts Sync Error', err?.message || 'Could not sync to Google Contacts.', 'error');
      return null;
    }
  };

  const exportAppointmentsToSheet = async (): Promise<string | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    try {
      const headers = ['Token', 'Date', 'Time', 'Patient Name', 'Phone', 'Doctor', 'Department', 'Status', 'Reason'];
      const rows = appointments.map((a) => [
        a.tokenNumber,
        a.appointmentDate,
        a.appointmentTime,
        a.patientName,
        a.patientPhone,
        a.doctorName,
        a.department,
        a.status,
        a.reason || '',
      ]);

      const result = await exportToGoogleSheet(token, 'OPD Appointments Log', headers, rows);
      showToast('Exported to Google Sheets', 'Created new spreadsheet in your Google Drive!', 'success');
      logAudit('sheet.export', 'GoogleSheets', `Exported ${rows.length} appointments to Google Sheets`);
      return result.spreadsheetUrl;
    } catch (err: any) {
      console.error('Google Sheets export error:', err);
      showToast('Sheets Export Error', err?.message || 'Could not export to Google Sheets.', 'error');
      return null;
    }
  };

  const exportBillingToSheet = async (): Promise<string | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    try {
      const headers = ['Invoice #', 'Date', 'Patient Name', 'Consultation Fee', 'Medicine Charges', 'Total (INR)', 'Payment Status', 'Method'];
      const rows = billings.map((b) => [
        b.invoiceNumber,
        b.createdAt.split('T')[0],
        b.patientName,
        b.consultationFee,
        b.medicineCharges,
        b.totalAmount,
        b.paymentStatus,
        b.paymentMethod || 'PENDING',
      ]);

      const result = await exportToGoogleSheet(token, 'Clinic Daily Revenue & Billing Ledger', headers, rows);
      showToast('Billing Exported to Sheets', 'Revenue ledger generated in Google Sheets.', 'success');
      logAudit('sheet.export', 'GoogleSheets', `Exported ${rows.length} billing rows to Google Sheets`);
      return result.spreadsheetUrl;
    } catch (err: any) {
      console.error('Billing export error:', err);
      showToast('Sheets Export Error', err?.message || 'Could not export billing ledger.', 'error');
      return null;
    }
  };

  const exportPatientsToSheet = async (): Promise<string | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    try {
      const headers = ['Patient Code', 'Name', 'Phone', 'Email', 'Age', 'Gender', 'Blood Group', 'Allergies', 'Chronic Conditions'];
      const rows = patients.map((p) => [
        p.patientCode,
        p.name,
        p.phone,
        p.email || '',
        p.age,
        p.gender,
        p.bloodGroup,
        p.allergies.join('; '),
        p.chronicConditions.join('; '),
      ]);

      const result = await exportToGoogleSheet(token, 'Patient Master Directory', headers, rows);
      showToast('Patient Directory Exported', 'Exported master directory to Google Sheets.', 'success');
      logAudit('sheet.export', 'GoogleSheets', `Exported ${rows.length} patients to Google Sheets`);
      return result.spreadsheetUrl;
    } catch (err: any) {
      console.error('Patients export error:', err);
      showToast('Sheets Export Error', err?.message || 'Could not export patient directory.', 'error');
      return null;
    }
  };

  const sendAppointmentConfirmationEmail = async (appointmentId: string): Promise<string | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    const appt = appointments.find((a) => a.id === appointmentId);
    if (!appt) {
      showToast('Appointment Not Found', 'Could not find appointment to send email.', 'error');
      return null;
    }

    const patient = patients.find((p) => p.id === appt.patientId);
    const toEmail = patient?.email;
    if (!toEmail) {
      showToast('Email Not Available', 'Patient does not have an email registered.', 'warning');
      return null;
    }

    try {
      const result = await sendGmailMessage(token, {
        to: toEmail,
        subject: `OPD Appointment Token: ${appt.tokenNumber} - Apex Metro Clinic`,
        bodyHtml: `
          <p>Dear <strong>${appt.patientName}</strong>,</p>
          <p>Your appointment has been confirmed with <strong>${appt.doctorName}</strong>.</p>
          <div style="background: #f8fafc; border: 1px solid #cbd5e1; padding: 16px; border-radius: 6px; margin: 16px 0;">
            <h3 style="margin: 0 0 10px 0; color: #0f766e;">Appointment Details</h3>
            <p style="margin: 4px 0;"><strong>Token:</strong> ${appt.tokenNumber}</p>
            <p style="margin: 4px 0;"><strong>Date:</strong> ${appt.appointmentDate}</p>
            <p style="margin: 4px 0;"><strong>Time:</strong> ${appt.appointmentTime}</p>
            <p style="margin: 4px 0;"><strong>Specialty:</strong> ${appt.department}</p>
            <p style="margin: 4px 0;"><strong>Status:</strong> ${appt.status}</p>
          </div>
          <p>Thank you for choosing Apex Metro Clinic.</p>
        `,
      });

      showToast('Email Dispatched via Gmail', `Sent confirmation to ${toEmail}.`, 'success');
      logAudit('gmail.send', 'Gmail', `Sent confirmation email for token ${appt.tokenNumber} to ${toEmail}`);
      return result.messageId;
    } catch (err: any) {
      console.error('Gmail send error:', err);
      showToast('Gmail Send Error', err?.message || 'Could not send email via Gmail.', 'error');
      return null;
    }
  };

  const sendPrescriptionEmail = async (prescriptionId: string): Promise<string | null> => {
    const token = await ensureWorkspaceToken();
    if (!token) return null;

    const rx = prescriptions.find((r) => r.id === prescriptionId);
    if (!rx) {
      showToast('Prescription Not Found', 'Could not find prescription.', 'error');
      return null;
    }

    const patient = patients.find((p) => p.id === rx.patientId);
    const toEmail = patient?.email;
    if (!toEmail) {
      showToast('Email Not Available', 'Patient does not have an email registered.', 'warning');
      return null;
    }

    const medRows = rx.medicines
      .map(
        (m) =>
          `<tr>
            <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><strong>${m.medicineName}</strong></td>
            <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${m.dosage}</td>
            <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${m.frequency}</td>
            <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;">${m.duration}</td>
            <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; font-size: 12px; color: #475569;">${m.instructions}</td>
          </tr>`
      )
      .join('');

    try {
      const result = await sendGmailMessage(token, {
        to: toEmail,
        subject: `E-Prescription & Consultation Summary: ${rx.patientName} (${rx.diagnosis})`,
        bodyHtml: `
          <p>Dear <strong>${rx.patientName}</strong>,</p>
          <p>Here is your official digital prescription from <strong>${rx.doctorName}</strong>.</p>
          
          <div style="background: #f1f5f9; padding: 12px; border-radius: 6px; margin: 12px 0;">
            <p style="margin: 3px 0;"><strong>Clinical Diagnosis:</strong> ${rx.diagnosis}</p>
            ${rx.vitals ? `<p style="margin: 3px 0; font-size: 12px;"><strong>Vitals Recorded:</strong> BP: ${rx.vitals.bp || 'N/A'}, Pulse: ${rx.vitals.pulse || 'N/A'}, SpO2: ${rx.vitals.spo2 || 'N/A'}</p>` : ''}
            ${rx.followUpDate ? `<p style="margin: 3px 0;"><strong>Recommended Follow-up:</strong> ${rx.followUpDate}</p>` : ''}
          </div>

          <h4 style="margin: 16px 0 8px 0; color: #0f172a;">Prescribed Medicines:</h4>
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 13px;">
            <thead>
              <tr style="background: #e2e8f0;">
                <th style="padding: 8px;">Medicine</th>
                <th style="padding: 8px;">Dosage</th>
                <th style="padding: 8px;">Frequency</th>
                <th style="padding: 8px;">Duration</th>
                <th style="padding: 8px;">Instructions</th>
              </tr>
            </thead>
            <tbody>
              ${medRows}
            </tbody>
          </table>

          ${rx.advice ? `<p style="margin-top: 16px;"><strong>Doctor's Advice:</strong> ${rx.advice}</p>` : ''}
        `,
      });

      showToast('Prescription Emailed via Gmail', `Sent digital prescription to ${toEmail}.`, 'success');
      logAudit('gmail.send', 'Gmail', `Sent prescription ${rx.id} to ${toEmail}`);
      return result.messageId;
    } catch (err: any) {
      console.error('Gmail send error:', err);
      showToast('Gmail Send Error', err?.message || 'Could not send prescription via Gmail.', 'error');
      return null;
    }
  };

  const contextValue = useMemo(
    () => ({
      currentRole,
      setCurrentRole,
      activeDoctorId,
      setActiveDoctorId,
      doctors,
      appointments,
      patients,
      prescriptions,
      inventory,
      billings,
      auditLogs,
      doctorLeaves,
      isRealtimeConnected,
      lastSyncTime,
      bookAppointment,
      checkInPatient,
      startConsultation,
      completeConsultation,
      dispensePrescription,
      updateBillPayment,
      markDoctorLeave,
      addPatient,
      addInventoryItem,
      updateInventoryStock,
      workspaceToken,
      connectGoogleWorkspace,
      disconnectGoogleWorkspace,
      syncToCalendar,
      syncPatientToGoogleContacts,
      exportAppointmentsToSheet,
      exportBillingToSheet,
      exportPatientsToSheet,
      sendAppointmentConfirmationEmail,
      sendPrescriptionEmail,
      seedDefaultData,
      activeToast,
      dismissToast,
      showToast,
    }),
    [
      currentRole,
      activeDoctorId,
      doctors,
      appointments,
      patients,
      prescriptions,
      inventory,
      billings,
      auditLogs,
      doctorLeaves,
      isRealtimeConnected,
      lastSyncTime,
      workspaceToken,
      activeToast,
    ]
  );

  return (
    <ClinicContext.Provider value={contextValue}>
      {children}
    </ClinicContext.Provider>
  );
}

export function useClinic() {
  const context = useContext(ClinicContext);
  if (!context) {
    throw new Error('useClinic must be used within a ClinicProvider');
  }
  return context;
}
